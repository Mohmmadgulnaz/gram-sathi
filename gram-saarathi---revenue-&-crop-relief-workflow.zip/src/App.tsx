import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  AlertTriangle, 
  PlusCircle, 
  Bot, 
  BookOpen, 
  Download, 
  CheckCircle2, 
  MapPin, 
  Wheat, 
  Clock, 
  Search,
  Filter,
  ShieldAlert,
  Smartphone
} from 'lucide-react';
import { ReliefApplication, OfficerProfile, ApplicationStage, PriorityLevel } from './types/workflow';
import { INITIAL_APPLICATIONS } from './data/mockApplications';
import { Navbar } from './components/Navbar';
import { DashboardStats } from './components/DashboardStats';
import { ApplicationFilterBar } from './components/ApplicationFilterBar';
import { ApplicationCard } from './components/ApplicationCard';
import { WorkflowDetailModal } from './components/WorkflowDetailModal';
import { SanctionCertificateModal } from './components/SanctionCertificateModal';
import { AiAssistantDrawer } from './components/AiAssistantDrawer';
import { NewApplicationModal } from './components/NewApplicationModal';
import { ProjectDocsModal } from './components/ProjectDocsModal';
import { generateProjectZip, triggerDownloadBlob } from './services/zipExportService';

export default function App() {
  const [applications, setApplications] = useState<ReliefApplication[]>(INITIAL_APPLICATIONS);
  const [selectedApp, setSelectedApp] = useState<ReliefApplication | null>(null);
  const [certificateApp, setCertificateApp] = useState<ReliefApplication | null>(null);

  // Modals & Drawers state
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [isDocsOpen, setIsDocsOpen] = useState(false);
  const [isNewAppOpen, setIsNewAppOpen] = useState(false);
  const [isFieldMode, setIsFieldMode] = useState(false);
  const [isHindi, setIsHindi] = useState(true);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStage, setSelectedStage] = useState('ALL');
  const [selectedPanchayat, setSelectedPanchayat] = useState('ALL');
  const [selectedPriority, setSelectedPriority] = useState('ALL');

  // Officer Profile
  const [officerRole, setOfficerRole] = useState<'LEKHPAL' | 'TEHSILDAR' | 'CITIZEN_VIEW'>('LEKHPAL');

  const currentOfficer: OfficerProfile = useMemo(() => {
    if (officerRole === 'TEHSILDAR') {
      return {
        id: 'OFF-02',
        name: 'सुनील कुमार वर्मा',
        designation: 'तहसीलदार (स्वीकृति अधिकारी)',
        role: 'TEHSILDAR',
        halkaNumber: 'समस्त तहसील',
        tehsil: 'सदर',
        district: 'लखनऊ',
      };
    }
    if (officerRole === 'CITIZEN_VIEW') {
      return {
        id: 'CIT-01',
        name: 'नागरिक दृश्य (सार्वजनिक ट्रैकर)',
        designation: 'नागरिक पोर्टल',
        role: 'CITIZEN_VIEW',
        halkaNumber: '14',
        tehsil: 'सदर',
        district: 'लखनऊ',
      };
    }
    return {
      id: 'OFF-01',
      name: 'राजेश कुमार त्रिपाठी',
      designation: 'लेखपाल / पटवारी',
      role: 'LEKHPAL',
      halkaNumber: '14',
      tehsil: 'सदर',
      district: 'लखनऊ',
    };
  }, [officerRole]);

  // Stage counts for badges
  const stageCounts = useMemo(() => {
    const counts: Record<string, number> = {
      ALL: applications.length,
      SCRUTINY: 0,
      FIELD_INSPECT: 0,
      DECISION: 0,
      APPROVED: 0,
      RETURNED: 0,
      REJECTED: 0,
    };
    applications.forEach((a) => {
      counts[a.currentStage] = (counts[a.currentStage] || 0) + 1;
    });
    return counts;
  }, [applications]);

  // Filtered applications
  const filteredApplications = useMemo(() => {
    return applications.filter((app) => {
      // Stage filter
      if (selectedStage !== 'ALL' && app.currentStage !== selectedStage) {
        return false;
      }
      // Panchayat filter
      if (selectedPanchayat !== 'ALL' && app.applicant.gramPanchayat !== selectedPanchayat) {
        return false;
      }
      // Priority filter
      if (selectedPriority !== 'ALL') {
        if (selectedPriority === 'URGENT' && app.priority !== 'URGENT') return false;
        if (selectedPriority === 'HIGH_DAMAGE' && app.priority !== 'HIGH_DAMAGE') return false;
        if (selectedPriority === 'MARGINAL_FARMER' && !app.applicant.category.includes('सीमान्त')) return false;
      }
      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = app.applicant.name.toLowerCase().includes(q) || app.applicant.nameEn.toLowerCase().includes(q);
        const matchAadhaar = app.applicant.aadhaarLast4.includes(q);
        const matchKhasra = app.landDetails.khasraNumber.includes(q);
        const matchId = app.id.toLowerCase().includes(q);
        const matchVillage = app.applicant.village.toLowerCase().includes(q);
        if (!matchName && !matchAadhaar && !matchKhasra && !matchId && !matchVillage) {
          return false;
        }
      }
      return true;
    });
  }, [applications, selectedStage, selectedPanchayat, selectedPriority, searchQuery]);

  // Handle application update from workflow steps
  const handleUpdateApp = (updatedApp: ReliefApplication) => {
    setApplications((prev) =>
      prev.map((a) => (a.id === updatedApp.id ? updatedApp : a))
    );
    setSelectedApp(updatedApp);
  };

  // Handle new claim registration
  const handleAddNewApp = (newApp: ReliefApplication) => {
    setApplications((prev) => [newApp, ...prev]);
    setSelectedApp(newApp);
  };

  // Handle ZIP export
  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    try {
      const blob = await generateProjectZip();
      triggerDownloadBlob(blob, 'gram-saarathi-revenue-workflow.zip');
    } catch (err) {
      console.error('ZIP failed:', err);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  // Urgent triage count
  const urgentCount = applications.filter(a => a.priority === 'URGENT').length;

  return (
    <div className={`min-h-screen ${isFieldMode ? 'bg-amber-50/40 text-slate-950 font-medium' : 'bg-slate-100 text-slate-900'}`}>
      {/* Navbar */}
      <Navbar
        currentOfficer={currentOfficer}
        onSwitchOfficer={setOfficerRole}
        isFieldMode={isFieldMode}
        onToggleFieldMode={() => setIsFieldMode(!isFieldMode)}
        isHindi={isHindi}
        onToggleLanguage={() => setIsHindi(!isHindi)}
        onOpenAssistant={() => setIsAssistantOpen(true)}
        onOpenDocs={() => setIsDocsOpen(true)}
        onOpenNewApp={() => setIsNewAppOpen(true)}
        onDownloadZip={handleDownloadZip}
        isDownloadingZip={isDownloadingZip}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Priority Attention Triage Alert Bar */}
        {urgentCount > 0 && (
          <div className="mb-6 p-3.5 rounded-xl bg-gradient-to-r from-rose-600 via-rose-700 to-amber-700 text-white shadow-md flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <span className="font-bold text-sm block">
                  {isHindi 
                    ? `⚠️ ध्यान दें: ${urgentCount} आवेदन अति आवश्यक (SLA समय सीमा 48 घंटे शेष) हैं!` 
                    : `⚠️ Immediate Attention: ${urgentCount} applications have SLA expiring within 48 hours!`}
                </span>
                <span className="text-xs text-rose-100">
                  {isHindi 
                    ? 'प्राकृतिक आपदा राहत नियमावली के अंतर्गत 7 दिवसीय निस्तारण अनिवार्य है।' 
                    : 'Mandatory 7-day disposal required under disaster relief code.'}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                setSelectedPriority('URGENT');
                setSelectedStage('ALL');
              }}
              className="px-3.5 py-1.5 rounded-lg bg-white text-rose-900 font-bold text-xs hover:bg-rose-50 shadow transition-all"
            >
              {isHindi ? 'अति आवश्यक प्रकरण देखें' : 'View Urgent Queue'}
            </button>
          </div>
        )}

        {/* Dashboard Statistics Overview */}
        <DashboardStats
          applications={applications}
          isHindi={isHindi}
          onFilterByCard={(stage) => {
            if (stage === 'URGENT') {
              setSelectedPriority('URGENT');
              setSelectedStage('ALL');
            } else {
              setSelectedStage(stage);
              setSelectedPriority('ALL');
            }
          }}
        />

        {/* Filter and Search Bar */}
        <ApplicationFilterBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedStage={selectedStage}
          onSelectStage={setSelectedStage}
          selectedPanchayat={selectedPanchayat}
          onSelectPanchayat={setSelectedPanchayat}
          selectedPriority={selectedPriority}
          onSelectPriority={setSelectedPriority}
          isHindi={isHindi}
          stageCounts={stageCounts}
        />

        {/* Applications List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500 px-1 font-medium">
            <span>
              {isHindi ? 'प्रदर्शित आवेदन: ' : 'Showing Applications: '}
              <strong className="text-slate-800">{filteredApplications.length}</strong> {isHindi ? 'प्रकरण' : 'claims'}
            </span>
            <span>
              {isHindi ? 'हल्का:' : 'Halka:'} <strong>{currentOfficer.halkaNumber}</strong> ({currentOfficer.tehsil})
            </span>
          </div>

          {filteredApplications.length > 0 ? (
            <div className="grid grid-cols-1 gap-3.5">
              {filteredApplications.map((app) => (
                <ApplicationCard
                  key={app.id}
                  app={app}
                  isHindi={isHindi}
                  isFieldMode={isFieldMode}
                  onSelect={(selected) => setSelectedApp(selected)}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-500">
              <Wheat className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h4 className="font-bold text-slate-800 text-base">
                {isHindi ? 'कोई आवेदन नहीं मिला' : 'No Applications Found'}
              </h4>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                {isHindi 
                  ? 'चयनित फिल्टर या खोज शब्दों के अनुसार कोई रिकॉर्ड उपलब्ध नहीं है। कृपया फिल्टर रीसेट करें।' 
                  : 'No matching records found for the chosen filters. Try clearing search criteria.'}
              </p>
              <button
                onClick={() => {
                  setSelectedStage('ALL');
                  setSelectedPanchayat('ALL');
                  setSelectedPriority('ALL');
                  setSearchQuery('');
                }}
                className="mt-4 px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold"
              >
                {isHindi ? 'सभी फिल्टर रीसेट करें' : 'Reset All Filters'}
              </button>
            </div>
          )}
        </div>
      </main>

      {/* Floating Action Trigger for Mobile/Tablet Field Officers */}
      <div className="fixed bottom-5 right-5 z-40 flex items-center gap-2">
        <button
          onClick={() => setIsAssistantOpen(true)}
          className="w-12 h-12 rounded-full bg-indigo-700 text-white shadow-xl flex items-center justify-center hover:bg-indigo-600 border border-indigo-400 transition-all hover:scale-105"
          title={isHindi ? 'एआई सहायक' : 'AI Assistant'}
        >
          <Bot className="w-6 h-6 text-amber-300" />
        </button>

        <button
          onClick={() => setIsNewAppOpen(true)}
          className="px-4 h-12 rounded-full bg-emerald-700 text-white shadow-xl flex items-center gap-2 hover:bg-emerald-600 border border-emerald-500 font-bold text-xs transition-all hover:scale-105"
        >
          <PlusCircle className="w-5 h-5" />
          <span className="hidden sm:inline">{isHindi ? 'नया आवेदन' : 'New Claim'}</span>
        </button>
      </div>

      {/* Footer */}
      <footer className="mt-16 bg-white border-t border-slate-200 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-800" />
            <span>
              <strong>ग्राम सारथी (Gram Saarathi)</strong> • {isHindi ? 'डिजिटल राजस्व कार्यप्रवाह प्रणाली 2026' : 'Digital Revenue Workflow System'}
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>SDRF/NDRF शासनादेश 412/2024-25</span>
            <span>•</span>
            <button onClick={() => setIsDocsOpen(true)} className="text-emerald-700 hover:underline font-semibold">
              {isHindi ? 'परियोजना डॉक्स व ज़िप' : 'Docs & ZIP'}
            </button>
            <span>•</span>
            <span className="font-mono text-slate-400">v1.0.0</span>
          </div>
        </div>
      </footer>

      {/* 3-Step Sequential Workflow Detail Modal */}
      {selectedApp && (
        <WorkflowDetailModal
          app={selectedApp}
          currentOfficer={currentOfficer}
          isHindi={isHindi}
          onClose={() => setSelectedApp(null)}
          onUpdateApp={handleUpdateApp}
          onViewSanctionCertificate={(app) => setCertificateApp(app)}
        />
      )}

      {/* Printable Sanction Certificate Modal */}
      {certificateApp && (
        <SanctionCertificateModal
          app={certificateApp}
          isHindi={isHindi}
          onClose={() => setCertificateApp(null)}
        />
      )}

      {/* Interactive AI Assistant Drawer */}
      <AiAssistantDrawer
        isOpen={isAssistantOpen}
        onClose={() => setIsAssistantOpen(false)}
        isHindi={isHindi}
        activeAppContext={selectedApp}
      />

      {/* New Claim Registration Modal */}
      <NewApplicationModal
        isOpen={isNewAppOpen}
        onClose={() => setIsNewAppOpen(false)}
        isHindi={isHindi}
        onSubmit={handleAddNewApp}
      />

      {/* Project Documentation & ZIP Download Modal */}
      <ProjectDocsModal
        isOpen={isDocsOpen}
        onClose={() => setIsDocsOpen(false)}
        isHindi={isHindi}
      />
    </div>
  );
}
