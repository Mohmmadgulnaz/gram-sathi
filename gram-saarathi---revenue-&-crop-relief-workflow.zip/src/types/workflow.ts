export type ApplicationStage = 
  | 'SCRUTINY'        // चरण 1: प्रारंभिक दस्तावेज़ व खतौनी सत्यापन
  | 'FIELD_INSPECT'   // चरण 2: मौका मुआयना व फसल क्षति स्थल निरीक्षण
  | 'DECISION'        // चरण 3: संस्तुति, पंचनामा व अंतिम अनुमोदन
  | 'APPROVED'        // संस्वीकृत (Approved)
  | 'REJECTED'        // अस्वीकृत (Rejected)
  | 'RETURNED';       // संशोधन हेतु वापस (Returned for correction)

export type PriorityLevel = 'NORMAL' | 'URGENT' | 'HIGH_DAMAGE' | 'MARGINAL_FARMER';

export interface Applicant {
  id: string;
  name: string;
  nameEn: string;
  fatherOrHusbandName: string;
  gender: 'M' | 'F' | 'O';
  age: number;
  phone: string;
  aadhaarLast4: string;
  village: string;
  villageEn: string;
  gramPanchayat: string;
  gramPanchayatEn: string;
  category: 'सीमान्त (<1हे.)' | 'लघु (1-2हे.)' | 'सामान्य (>2हे.)';
  bankAccount: string;
  bankName: string;
  ifsc: string;
}

export interface LandDetails {
  khasraNumber: string;
  khatauniNumber: string;
  ownerNameInKhatauni: string;
  ownerNameInKhatauniEn: string;
  totalKhatauniAreaHectare: number;
  claimedAreaHectare: number;
  cropType: string;
  cropTypeEn: string;
  irrigationType: 'सिंचित (Irrigated)' | 'असिंचित (Rainfed)';
  coSharersCount: number;
  landMutationStatus: 'अद्यतन (Updated)' | 'लंबित (Pending)';
}

export interface Witness {
  name: string;
  designation: string;
  phone?: string;
  aadhaarLast4?: string;
}

export interface FieldInspectionData {
  inspectionDate: string;
  inspectorName: string;
  inspectorDesignation: string;
  gpsCoordinates: string;
  gpsAccuracyMeters: number;
  damageReason: string;
  weatherEventDate: string;
  assessedDamagePercentage: number;
  cropConditionNotes: string;
  cropPhotoUrl: string;
  witnesses: Witness[];
  voiceNotesTranscript?: string;
}

export interface AIAnalysisResult {
  step: 'STEP1_DOCS' | 'STEP2_FIELD' | 'STEP3_DRAFT';
  generatedAt: string;
  summary: string;
  confidenceScore: number;
  flags: string[];
  recommendation: string;
  data: any;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  stage: ApplicationStage;
  action: string;
  actionEn: string;
  officerName: string;
  officerRole: string;
  remarks: string;
  aiSnapshot?: string;
}

export interface SanctionDecisionData {
  decision: 'APPROVE' | 'REJECT' | 'RETURN';
  decidedAt?: string;
  decidedBy?: string;
  officerDesignation?: string;
  panchnamaText?: string;
  sanctionAmount?: number;
  calculatedRatePerHectare?: number;
  rejectionReason?: string;
  rejectionRuleRef?: string;
  returnRemarks?: string;
  missingDocuments?: string[];
  digitalSignatureHash?: string;
}

export interface ReliefApplication {
  id: string; // e.g. "KRF-2026-UP-8842"
  submissionDate: string;
  currentStage: ApplicationStage;
  priority: PriorityLevel;
  slaDeadline: string; // ISO date
  applicant: Applicant;
  landDetails: LandDetails;
  fieldInspection?: FieldInspectionData;
  aiAnalyses: {
    step1Docs?: AIAnalysisResult;
    step2Field?: AIAnalysisResult;
    step3Draft?: AIAnalysisResult;
  };
  decision?: SanctionDecisionData;
  auditTrail: AuditLogEntry[];
  documents: {
    title: string;
    type: 'AADHAAR' | 'KHATAUNI' | 'BANK_PASSBOOK' | 'AFFIDAVIT' | 'FIELD_PHOTO';
    verified: boolean;
    url?: string;
  }[];
}

export interface OfficerProfile {
  id: string;
  name: string;
  designation: string;
  role: 'LEKHPAL' | 'TEHSILDAR' | 'CITIZEN_VIEW';
  halkaNumber: string;
  tehsil: string;
  district: string;
}
