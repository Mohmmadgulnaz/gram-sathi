import React, { useState } from 'react';
import { X, Send, Bot, Sparkles, User, Mic, MicOff, BookOpen, Lightbulb } from 'lucide-react';
import { askAssistantAI } from '../services/aiService';

interface AiAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  isHindi: boolean;
  activeAppContext?: any;
}

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

export const AiAssistantDrawer: React.FC<AiAssistantDrawerProps> = ({
  isOpen,
  onClose,
  isHindi,
  activeAppContext,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'ai',
      text: isHindi
        ? 'नमस्ते! मैं "ग्राम सारथी" राजस्व एवं आपदा राहत एआई सहायक हूँ। आप मुझसे SDRF नियमावली, खसरा-खतौनी सत्यापन, मौका मुआयना या पंचनामा संबंधी कोई भी प्रश्न पूछ सकते हैं।'
        : 'Hello! I am Gram Saarathi AI Assistant. Ask me about SDRF crop relief rules, land records, or inspection procedures.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);

  const samplePrompts = [
    'क्या 2 हेक्टेयर से अधिक भूमि वाले कृषक SDRF के पात्र हैं?',
    'सह-खातेदार होने पर सहमति पत्र के क्या नियम हैं?',
    '33% से कम फसल क्षति होने पर क्या आदेश जारी होगा?',
    'पंचनामा में कौन-कौन से गवाह मान्य होते हैं?',
  ];

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const reply = await askAssistantAI(textToSend, activeAppContext);
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: reply || 'क्षमा करें, प्रतिक्रिया प्राप्त नहीं हो सकी।',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleMicToggle = () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }
    setIsRecording(true);
    setTimeout(() => {
      setInputQuery('सह-खातेदार होने पर सहमति पत्र के क्या नियम हैं?');
      setIsRecording(false);
    }, 1800);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-96 bg-white shadow-2xl border-l border-slate-300 flex flex-col">
      {/* Top Header */}
      <div className="bg-gradient-to-r from-emerald-900 to-indigo-900 text-white p-4 flex items-center justify-between border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm">
              {isHindi ? 'ग्राम सारथी - एआई राजस्व सहायक' : 'Gram Saarathi AI Assistant'}
            </h3>
            <p className="text-[11px] text-emerald-200">
              {isHindi ? 'राजस्व संहिता व SDRF नियमावली विशेषज्ञ' : 'Revenue Code & SDRF Specialist'}
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Suggested Quick Questions */}
      <div className="p-3 bg-slate-50 border-b border-slate-200 overflow-x-auto">
        <div className="text-[11px] font-semibold text-slate-500 mb-1.5 flex items-center gap-1">
          <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
          <span>{isHindi ? 'त्वरित प्रश्न सुझाव:' : 'Suggested questions:'}</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {samplePrompts.map((p, i) => (
            <button
              key={i}
              onClick={() => handleSend(p)}
              className="text-[11px] text-slate-700 bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-800 px-2.5 py-1 rounded-full text-left transition-all"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Body */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex items-start gap-2 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {m.sender === 'ai' && (
              <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center shrink-0 mt-1">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-xl p-3 text-xs leading-relaxed ${
                m.sender === 'user'
                  ? 'bg-emerald-700 text-white rounded-tr-none'
                  : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none shadow-sm whitespace-pre-wrap'
              }`}
            >
              <p>{m.text}</p>
              <span
                className={`block text-[9px] mt-1 text-right ${
                  m.sender === 'user' ? 'text-emerald-200' : 'text-slate-400'
                }`}
              >
                {m.timestamp}
              </span>
            </div>

            {m.sender === 'user' && (
              <div className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center shrink-0 mt-1">
                <User className="w-3.5 h-3.5" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 text-xs text-indigo-700 bg-indigo-50 p-2.5 rounded-lg border border-indigo-200 w-fit">
            <Sparkles className="w-4 h-4 animate-spin text-amber-500" />
            <span>{isHindi ? 'एआई सहायक विचार कर रहा है...' : 'AI is thinking...'}</span>
          </div>
        )}
      </div>

      {/* Chat Input Bar */}
      <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
        <button
          onClick={handleMicToggle}
          type="button"
          className={`p-2 rounded-lg border transition-all ${
            isRecording
              ? 'bg-rose-600 text-white animate-pulse border-rose-600'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
          }`}
          title={isHindi ? 'बोलकर प्रश्न पूछें' : 'Voice Query'}
        >
          {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-emerald-700" />}
        </button>

        <input
          type="text"
          value={inputQuery}
          onChange={(e) => setInputQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder={isHindi ? 'राजस्व नियम या आवेदन संबंधी प्रश्न पूछें...' : 'Ask revenue rules or claim details...'}
          className="flex-1 p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        />

        <button
          onClick={() => handleSend()}
          disabled={!inputQuery.trim() || isLoading}
          className="p-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg transition-all disabled:opacity-40"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
