import React, { useState } from 'react';
import { 
  FileCheck2, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  User, 
  Building, 
  ArrowRight, 
  RotateCcw,
  CheckSquare,
  Square,
  ShieldCheck,
  CreditCard,
  FileSpreadsheet
} from 'lucide-react';
import { ReliefApplication } from '../types/workflow';
import { verifyDocumentsAI } from '../services/aiService';

interface Step1DocumentScrutinyProps {
  app: ReliefApplication;
  isHindi: boolean;
  onAdvanceToField: (updatedApp: ReliefApplication, remarks: string) => void;
  onReturnForCorrection: (updatedApp: ReliefApplication, reason: string) => void;
}

export const Step1DocumentScrutiny: React.FC<Step1DocumentScrutinyProps> = ({
  app,
  isHindi,
  onAdvanceToField,
  onReturnForCorrection,
}) => {
  const [isVerifying, setIsVerifying] = useState(false);
  const [currentApp, setCurrentApp] = useState<ReliefApplication>(app);
  const [officerNotes, setOfficerNotes] = useState(
    'आधार व खतौनी का मिलान किया गया। प्रथम दृष्टया कृषक पात्र हैं।'
  );
  
  // Checklist states
  const [checks, setChecks] = useState({
    aadhaarVerified: true,
    khatauniVerified: true,
    bankVerified: true,
    coSharerVerified: app.landDetails.coSharersCount <= 1,
  });

  const toggleCheck = (key: keyof typeof checks) => {
    setChecks(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const allChecked = checks.aadhaarVerified && checks.khatauniVerified && checks.bankVerified;

  const handleRunAICheck = async () => {
    setIsVerifying(true);
    try {
      const result = await verifyDocumentsAI(currentApp.applicant, currentApp.landDetails);
      if (result.success && result.analysis) {
        const updated = {
          ...currentApp,
          aiAnalyses: {
            ...currentApp.aiAnalyses,
            step1Docs: {
              step: 'STEP1_DOCS' as const,
              generatedAt: new Date().toISOString(),
              summary: `${result.analysis.nameMatchStatus} (${result.analysis.matchScore}%)। ${result.analysis.khasraAreaValidation}`,
              confidenceScore: result.analysis.matchScore || 90,
              flags: result.analysis.flags || [],
              recommendation: result.analysis.officerChecklistRecommendation || 'दस्तावेज़ सत्यापित।',
              data: result.analysis,
            },
          },
        };
        setCurrentApp(updated);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsVerifying(false);
    }
  };

  const handleAdvance = () => {
    onAdvanceToField(currentApp, officerNotes);
  };

  const handleReturn = () => {
    const reason = prompt(
      isHindi 
        ? 'संशोधन हेतु आपत्ति का विवरण दर्ज करें (उदा. सह-खातेदार एनओसी अपेक्षित, बैंक पासबुक अस्पष्ट):'
        : 'Enter return reason for citizen:'
    );
    if (reason) {
      onReturnForCorrection(currentApp, reason);
    }
  };

  const aiResult = currentApp.aiAnalyses.step1Docs?.data;

  return (
    <div className="space-y-6">
      {/* Step Header */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <span className="text-xs font-bold text-amber-800 uppercase tracking-wider bg-amber-200/70 px-2 py-0.5 rounded">
            {isHindi ? 'चरण 1 / 3: प्रारंभिक संवीक्षा' : 'Step 1 of 3: Scrutiny'}
          </span>
          <h3 className="text-lg font-bold text-slate-900 mt-1">
            {isHindi 
              ? 'आवेदक पहचान व राजस्व खतौनी मिलान सत्यापन' 
              : 'Applicant Identity & Bhulekh Land Record Cross-Verification'}
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            {isHindi 
              ? 'आधार, बैंक खाता और राजस्व खतौनी में दर्ज रकबा व सह-खातेदारों का सत्यापन करें।' 
              : 'Cross-check applicant Aadhaar, Bank DBT status, and Khasra/Khatauni land parcel.'}
          </p>
        </div>

        {/* AI Action Button */}
        <button
          onClick={handleRunAICheck}
          disabled={isVerifying}
          className="shrink-0 inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-700 hover:bg-indigo-600 text-white text-xs sm:text-sm font-semibold shadow-md border border-indigo-500/30 transition-all disabled:opacity-50"
        >
          <Sparkles className={`w-4 h-4 text-amber-300 ${isVerifying ? 'animate-spin' : ''}`} />
          <span>
            {isVerifying 
              ? (isHindi ? 'एआई जांच जारी है...' : 'AI Analyzing...') 
              : (isHindi ? '⚡ एआई खतौनी व नाम मिलान जांचें' : '⚡ Run AI Cross-Check')}
          </span>
        </button>
      </div>

      {/* Side-by-Side Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Column 1: Applicant Claim (Citizen Submission) */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <User className="w-4 h-4 text-emerald-600" />
              <span>{isHindi ? 'प्रार्थी द्वारा प्रस्तुत दावा विवरण' : 'Applicant Claimed Profile'}</span>
            </h4>
            <span className="text-[11px] font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-600">
              CSC Online
            </span>
          </div>

          <div className="mt-3 space-y-2.5 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{isHindi ? 'आवेदक का नाम:' : 'Name:'}</span>
              <span className="font-bold text-slate-900">{currentApp.applicant.name}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{isHindi ? 'पिता / पति का नाम:' : 'Father/Husband:'}</span>
              <span className="font-medium text-slate-800">{currentApp.applicant.fatherOrHusbandName}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{isHindi ? 'आधार संख्या:' : 'Aadhaar (Last 4):'}</span>
              <span className="font-mono font-bold text-slate-800">XXXX-XXXX-{currentApp.applicant.aadhaarLast4}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{isHindi ? 'ग्राम व पंचायत:' : 'Village & GP:'}</span>
              <span className="font-medium text-slate-800">
                {currentApp.applicant.village}, {currentApp.applicant.gramPanchayat}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{isHindi ? 'दावाकृत रकबा:' : 'Claimed Area:'}</span>
              <span className="font-bold text-emerald-800">
                {currentApp.landDetails.claimedAreaHectare} {isHindi ? 'हेक्टेयर' : 'Ha'}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{isHindi ? 'फसल:' : 'Crop:'}</span>
              <span className="font-medium text-slate-800">{currentApp.landDetails.cropType}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-500">{isHindi ? 'बैंक खाता व IFSC:' : 'Bank Account & IFSC:'}</span>
              <span className="font-mono text-slate-800 text-right">
                {currentApp.applicant.bankAccount} ({currentApp.applicant.ifsc})
              </span>
            </div>
          </div>
        </div>

        {/* Column 2: Official Revenue Land Record (Bhulekh) */}
        <div className="bg-slate-50 rounded-xl border border-slate-300 p-4 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-amber-700" />
              <span>{isHindi ? 'राजस्व भूलेख खतौनी रिकॉर्ड (2025-26)' : 'Bhulekh Land Record (Official)'}</span>
            </h4>
            <span className="text-[11px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
              {isHindi ? 'अद्यतन सत्यापित' : 'Live Verified'}
            </span>
          </div>

          <div className="mt-3 space-y-2.5 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-200">
              <span className="text-slate-600">{isHindi ? 'खतौनी खाता संख्या:' : 'Khatauni Khata No:'}</span>
              <span className="font-mono font-bold text-slate-900">{currentApp.landDetails.khatauniNumber}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-200">
              <span className="text-slate-600">{isHindi ? 'खसरा / गाटा संख्या:' : 'Khasra / Gata No:'}</span>
              <span className="font-mono font-bold text-slate-900">{currentApp.landDetails.khasraNumber}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-200">
              <span className="text-slate-600">{isHindi ? 'खतौनी में दर्ज खातेदार:' : 'Name in Khatauni:'}</span>
              <span className="font-bold text-slate-900 bg-amber-100/70 px-1.5 py-0.5 rounded">
                {currentApp.landDetails.ownerNameInKhatauni}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-200">
              <span className="text-slate-600">{isHindi ? 'कुल खतौनी रकबा:' : 'Total Parcel Area:'}</span>
              <span className="font-bold text-slate-800">
                {currentApp.landDetails.totalKhatauniAreaHectare} {isHindi ? 'हेक्टेयर' : 'Ha'}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-200">
              <span className="text-slate-600">{isHindi ? 'सह-खातेदारों की संख्या:' : 'Co-Sharers:'}</span>
              <span className={`font-semibold ${currentApp.landDetails.coSharersCount > 1 ? 'text-amber-800' : 'text-slate-800'}`}>
                {currentApp.landDetails.coSharersCount} {isHindi ? 'खातेदार' : 'Owners'}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-200">
              <span className="text-slate-600">{isHindi ? 'सिंचाई श्रेणी:' : 'Irrigation Type:'}</span>
              <span className="font-medium text-slate-800">{currentApp.landDetails.irrigationType}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-600">{isHindi ? 'नामांतरण स्थिति:' : 'Mutation Status:'}</span>
              <span className="text-emerald-700 font-semibold">{currentApp.landDetails.landMutationStatus}</span>
            </div>
          </div>
        </div>
      </div>

      {/* AI Analysis Result Card */}
      {currentApp.aiAnalyses.step1Docs && (
        <div className="bg-gradient-to-r from-indigo-50 via-slate-50 to-indigo-50 border border-indigo-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between pb-2 border-b border-indigo-100">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <h4 className="font-bold text-indigo-950 text-sm">
                {isHindi ? 'एआई दस्तावेज़ व खतौनी विश्लेषण परिणाम' : 'AI Cross-Verification Intelligence'}
              </h4>
            </div>
            <span className="text-xs font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded border border-indigo-200">
              {isHindi ? 'विश्वसनीयता स्कोर:' : 'Match Score:'} {currentApp.aiAnalyses.step1Docs.confidenceScore}%
            </span>
          </div>

          <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="bg-white p-3 rounded-lg border border-indigo-100">
              <span className="text-slate-500 font-medium block">
                {isHindi ? 'नाम मिलान स्थिति:' : 'Name Match Assessment:'}
              </span>
              <p className="font-bold text-slate-900 mt-0.5">
                {aiResult?.nameMatchStatus || 'ध्वन्यात्मक मेल (Phonetic Match)'}
              </p>
              <p className="text-[11px] text-slate-600 mt-1">
                {aiResult?.nameDiscrepancyNotes || 'आधार और खतौनी में नाम का विधिक मिलान सही है।'}
              </p>
            </div>

            <div className="bg-white p-3 rounded-lg border border-indigo-100">
              <span className="text-slate-500 font-medium block">
                {isHindi ? 'खसरा रकबा व अंश वैधता:' : 'Khasra Area & Legal Share:'}
              </span>
              <p className="text-[11px] text-slate-700 mt-1">
                {aiResult?.khasraAreaValidation || 'रकबा खतौनी सीमा के भीतर अनुकूल है।'}
              </p>
            </div>

            <div className="bg-white p-3 rounded-lg border border-indigo-100">
              <span className="text-slate-500 font-medium block">
                {isHindi ? 'दोहरा दावा / जोखिम जांच:' : 'Duplicate Claim Risk:'}
              </span>
              <p className="text-[11px] text-emerald-700 font-medium mt-1">
                {aiResult?.duplicateCheck || 'इस खसरा संख्या पर अन्य कोई सक्रिय दावा नहीं है।'}
              </p>
            </div>
          </div>

          {currentApp.aiAnalyses.step1Docs.recommendation && (
            <div className="mt-3 p-2.5 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <strong>{isHindi ? 'एआई अधिकारी अनुशंसा: ' : 'AI Recommendation: '}</strong>
                {currentApp.aiAnalyses.step1Docs.recommendation}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Field Worker Verification Checklist */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-700" />
          <span>{isHindi ? 'लेखपाल सत्यापन चेकलिस्ट (अंतिम निर्णय आपका है)' : 'Field Officer Verification Checklist'}</span>
        </h4>
        <p className="text-xs text-slate-500 mb-3">
          {isHindi 
            ? 'मौका मुआयने हेतु आगे बढ़ाने से पूर्व आवश्यक बिंदुओं की पुष्टि करें:' 
            : 'Confirm checks before advancing application to field inspection:'}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          <button
            type="button"
            onClick={() => toggleCheck('aadhaarVerified')}
            className={`flex items-center gap-2 p-2.5 rounded-lg border text-left transition-all ${
              checks.aadhaarVerified ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-medium' : 'bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            {checks.aadhaarVerified ? <CheckSquare className="w-4 h-4 text-emerald-700" /> : <Square className="w-4 h-4 text-slate-400" />}
            <span>{isHindi ? '1. आधार कार्ड व मूल निवास प्रमाण पत्र सत्यापित' : '1. Aadhaar & Residence Verified'}</span>
          </button>

          <button
            type="button"
            onClick={() => toggleCheck('khatauniVerified')}
            className={`flex items-center gap-2 p-2.5 rounded-lg border text-left transition-all ${
              checks.khatauniVerified ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-medium' : 'bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            {checks.khatauniVerified ? <CheckSquare className="w-4 h-4 text-emerald-700" /> : <Square className="w-4 h-4 text-slate-400" />}
            <span>{isHindi ? '2. खतौनी इंतखाब में नाम, गाटा व रकबा मिलान सही' : '2. Khatauni Name, Khasra & Area Matched'}</span>
          </button>

          <button
            type="button"
            onClick={() => toggleCheck('bankVerified')}
            className={`flex items-center gap-2 p-2.5 rounded-lg border text-left transition-all ${
              checks.bankVerified ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-medium' : 'bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            {checks.bankVerified ? <CheckSquare className="w-4 h-4 text-emerald-700" /> : <Square className="w-4 h-4 text-slate-400" />}
            <span>{isHindi ? '3. बैंक पासबुक प्रति संलग्न व खाता डीबीटी सक्रिय' : '3. Bank Passbook Attached & DBT Active'}</span>
          </button>

          <button
            type="button"
            onClick={() => toggleCheck('coSharerVerified')}
            className={`flex items-center gap-2 p-2.5 rounded-lg border text-left transition-all ${
              checks.coSharerVerified ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-medium' : 'bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            {checks.coSharerVerified ? <CheckSquare className="w-4 h-4 text-emerald-700" /> : <Square className="w-4 h-4 text-slate-400" />}
            <span>
              {isHindi 
                ? (currentApp.landDetails.coSharersCount > 1 ? '4. सह-खातेदार अनापत्ति / विधिक अंश पुष्ट' : '4. एकल खातेदार (सह-खातेदार विसंगति नहीं)')
                : '4. Co-sharer Share or Single Owner Verified'}
            </span>
          </button>
        </div>

        {/* Officer Remarks Field */}
        <div className="mt-4">
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            {isHindi ? 'लेखपाल संवीक्षा टिप्पणी (Officer Scrutiny Remarks):' : 'Officer Scrutiny Remarks:'}
          </label>
          <textarea
            rows={2}
            value={officerNotes}
            onChange={(e) => setOfficerNotes(e.target.value)}
            className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
          />
        </div>
      </div>

      {/* Action Footer */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
        <button
          onClick={handleReturn}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-orange-100 hover:bg-orange-200 text-orange-800 text-xs sm:text-sm font-semibold transition-all border border-orange-300"
        >
          <RotateCcw className="w-4 h-4" />
          <span>{isHindi ? 'संशोधन हेतु वापस प्रेषित करें' : 'Return for Correction'}</span>
        </button>

        <button
          onClick={handleAdvance}
          disabled={!allChecked}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs sm:text-sm font-bold shadow-md transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <span>{isHindi ? 'दस्तावेज़ सत्यापित ➔ चरण 2: मौका मुआयने हेतु अग्रसारित करें' : 'Verified ➔ Advance to Step 2: Field Inspection'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
