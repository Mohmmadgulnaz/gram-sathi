import React, { useState } from 'react';
import { 
  FileText, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  ArrowLeft, 
  Calculator, 
  Stamp, 
  ShieldAlert, 
  Printer, 
  Eye,
  FileCheck
} from 'lucide-react';
import { ReliefApplication, OfficerProfile } from '../types/workflow';
import { draftPanchnamaAI } from '../services/aiService';

interface Step3SanctionDecisionProps {
  app: ReliefApplication;
  currentOfficer: OfficerProfile;
  isHindi: boolean;
  onApprove: (updatedApp: ReliefApplication, sanctionAmount: number, panchnamaText: string) => void;
  onReject: (updatedApp: ReliefApplication, reason: string, ruleRef: string) => void;
  onReturn: (updatedApp: ReliefApplication, remarks: string, missingDocs: string[]) => void;
  onBackToField: () => void;
  onViewSanctionCertificate?: (app: ReliefApplication) => void;
}

export const Step3SanctionDecision: React.FC<Step3SanctionDecisionProps> = ({
  app,
  currentOfficer,
  isHindi,
  onApprove,
  onReject,
  onReturn,
  onBackToField,
  onViewSanctionCertificate,
}) => {
  const isIrrigated = app.landDetails.irrigationType.includes('सिंचित');
  const baseRatePerHa = isIrrigated ? 17000 : 8500;
  const damagePercent = app.fieldInspection?.assessedDamagePercentage || 65;
  const claimedArea = app.landDetails.claimedAreaHectare;

  // Auto SDRF calculation formula
  const calculatedAmount = Math.round(claimedArea * baseRatePerHa * (damagePercent / 100));

  const [sanctionAmount, setSanctionAmount] = useState<number>(
    app.decision?.sanctionAmount || calculatedAmount
  );

  const [panchnamaDraft, setPanchnamaDraft] = useState<string>(
    app.decision?.panchnamaText ||
      `आज दिनांक को प्रार्थी ${app.applicant.name} आत्मज ${app.applicant.fatherOrHusbandName}, निवासी ग्राम ${app.applicant.village}, ग्राम पंचायत ${app.applicant.gramPanchayat} के खसरा संख्या ${app.landDetails.khasraNumber} पर उपस्थित होकर फसल क्षति का स्थलीय निरीक्षण किया गया। निरीक्षण के समय उपस्थित पंचों ${
        app.fieldInspection?.witnesses?.map((w) => w.name).join(', ') || 'श्री जगदीश वर्मा व श्री रामसेवक पाल'
      } के समक्ष देखा गया कि ${app.landDetails.cropType} की फसल प्राकृतिक आपदा (${app.fieldInspection?.damageReason || 'ओलावृष्टि'}) से लगभग ${damagePercent}% क्षतिग्रस्त हुई है। SDRF शासनादेश के तहत यह प्रकरण 33% से अधिक क्षति श्रेणी में आता है। नियमानुसार ₹${calculatedAmount.toLocaleString('en-IN')}/- की अनुदान सहायता संस्वीकृत करने की संस्तुति की जाती है।`
  );

  const [isDraftingAI, setIsDraftingAI] = useState(false);
  const [currentApp, setCurrentApp] = useState<ReliefApplication>(app);

  // Rejection modal/state
  const [rejectionReason, setRejectionReason] = useState('फसल क्षति 33% न्यूनतम मानक से कम पाई गई।');
  const [rejectionRule, setRejectionRule] = useState('SDRF शासनादेश 2024-25 प्रस्तर 3(क)');
  const [showRejectBox, setShowRejectBox] = useState(false);

  // Return modal/state
  const [returnRemarks, setReturnRemarks] = useState('सह-खातेदारों का अनापत्ति शपथ पत्र (NOC) अपेक्षित है।');
  const [showReturnBox, setShowReturnBox] = useState(false);

  const handleGenerateAIDraft = async () => {
    setIsDraftingAI(true);
    try {
      const result = await draftPanchnamaAI(
        currentApp.applicant,
        currentApp.landDetails,
        {
          damagePercentage: damagePercent,
          damageReason: currentApp.fieldInspection?.damageReason || 'ओलावृष्टि व तेज वर्षा',
        },
        currentApp.fieldInspection?.witnesses || [],
        currentOfficer.name,
        currentOfficer.designation
      );

      if (result.success && result.draft) {
        setPanchnamaDraft(result.draft.panchnamaText);
        if (result.draft.sanctionCalculation?.recommendedAmount) {
          setSanctionAmount(result.draft.sanctionCalculation.recommendedAmount);
        }
        setCurrentApp({
          ...currentApp,
          aiAnalyses: {
            ...currentApp.aiAnalyses,
            step3Draft: {
              step: 'STEP3_DRAFT',
              generatedAt: new Date().toISOString(),
              summary: result.draft.recommendation,
              confidenceScore: 96,
              flags: result.draft.legalClauses || [],
              recommendation: result.draft.recommendation,
              data: result.draft,
            },
          },
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsDraftingAI(false);
    }
  };

  const handleApproveAction = () => {
    onApprove(currentApp, sanctionAmount, panchnamaDraft);
  };

  const handleConfirmReject = () => {
    onReject(currentApp, rejectionReason, rejectionRule);
  };

  const handleConfirmReturn = () => {
    onReturn(currentApp, returnRemarks, ['सह-खातेदार एनओसी', 'संशोधित रकबा']);
  };

  const isAlreadyApproved = app.currentStage === 'APPROVED';

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <span className="text-xs font-bold text-purple-800 uppercase tracking-wider bg-purple-200/70 px-2 py-0.5 rounded">
            {isHindi ? 'चरण 3 / 3: अंतिम संस्तुति व अनुमोदन' : 'Step 3 of 3: Sanction & Decision'}
          </span>
          <h3 className="text-lg font-bold text-slate-900 mt-1">
            {isHindi 
              ? 'आपदा राहत अनुदान गणना, पंचनामा विधिक आख्या व अधिकारी निर्णय' 
              : 'SDRF Relief Calculation, Legal Panchnama & Officer Call'}
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            {isHindi 
              ? 'एसडीआरएफ नियमों के अनुसार राहत राशि की गणना करें, पंचनामा आख्या जांचें और अंतिम आदेश पारित करें।' 
              : 'Compute statutory relief subsidy, review generated Hindi Panchnama, and issue final order.'}
          </p>
        </div>

        {/* AI Drafter Button */}
        {!isAlreadyApproved && (
          <button
            onClick={handleGenerateAIDraft}
            disabled={isDraftingAI}
            className="shrink-0 inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-700 hover:bg-indigo-600 text-white text-xs sm:text-sm font-semibold shadow-md border border-indigo-500/30 transition-all disabled:opacity-50"
          >
            <Sparkles className={`w-4 h-4 text-amber-300 ${isDraftingAI ? 'animate-spin' : ''}`} />
            <span>
              {isDraftingAI 
                ? (isHindi ? 'विधिक प्रारूपण जारी...' : 'Drafting Legal Memo...') 
                : (isHindi ? '⚡ एआई सरकारी पंचनामा प्रारूप तैयार करें' : '⚡ AI Draft Panchnama')}
            </span>
          </button>
        )}
      </div>

      {/* SDRF Relief Calculation Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Calculator className="w-4 h-4 text-emerald-700" />
            <span>{isHindi ? 'एसडीआरएफ (SDRF/NDRF) नियमानुसार अनुदान सहायता गणना' : 'SDRF Relief Grant Calculation'}</span>
          </h4>
          <span className="text-xs font-semibold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded border border-emerald-300">
            {isHindi ? 'मानक दर: ' : 'Norm Rate: '} ₹{baseRatePerHa.toLocaleString('en-IN')} / {isHindi ? 'हेक्टेयर' : 'Ha'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mt-3 text-xs">
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-slate-500 block">{isHindi ? 'सत्यापित रकबा:' : 'Verified Area:'}</span>
            <span className="text-base font-bold text-slate-800">{claimedArea} {isHindi ? 'हेक्टेयर' : 'Ha'}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">{app.landDetails.irrigationType}</span>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-slate-500 block">{isHindi ? 'प्रमाणित फसल क्षति:' : 'Assessed Loss:'}</span>
            <span className={`text-base font-bold ${damagePercent >= 70 ? 'text-rose-700' : 'text-amber-700'}`}>
              {damagePercent}%
            </span>
            <span className="text-[10px] text-emerald-700 font-semibold block mt-0.5">
              {damagePercent >= 33 ? (isHindi ? 'न्यूनतम 33% मानक पूर्ण' : '≥ 33% Norm Met') : (isHindi ? 'मानक से कम' : '<33%')}
            </span>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-slate-500 block">{isHindi ? 'गणना सूत्र:' : 'Formula:'}</span>
            <span className="font-mono text-slate-800 text-[11px] block mt-1">
              {claimedArea} Ha × ₹{baseRatePerHa} × {damagePercent}%
            </span>
          </div>

          <div className="bg-emerald-50 p-2.5 rounded-lg border border-emerald-300">
            <span className="text-emerald-800 font-semibold block">{isHindi ? 'अनुशंसित राहत राशि:' : 'Relief Amount:'}</span>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-xl font-black text-emerald-900">₹</span>
              <input
                type="number"
                aria-label={isHindi ? 'राहत राशि' : 'Relief Amount'}
                value={sanctionAmount}
                onChange={(e) => setSanctionAmount(parseInt(e.target.value, 10) || 0)}
                disabled={isAlreadyApproved}
                className="w-full text-xl font-black text-emerald-900 bg-transparent border-b border-emerald-400 focus:outline-none focus:border-emerald-700"
              />
            </div>
            <span className="text-[10px] text-emerald-700 block mt-0.5">{isHindi ? 'ट्रेजरी डीबीटी हेतु अनुमन्य' : 'Direct DBT Grant'}</span>
          </div>
        </div>
      </div>

      {/* Legal Panchnama & Inquiry Report (Editable by Officer) */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <FileText className="w-4 h-4 text-purple-700" />
            <span>{isHindi ? 'मौका मुआयना पंचनामा व संस्तुति आख्या (संपादनीय)' : 'Official Hindi Panchnama & Report (Editable)'}</span>
          </h4>
          <span className="text-[11px] text-slate-500 italic">
            {isHindi ? 'अधिकारी आवश्यकतानुसार पाठ में संशोधन कर सकते हैं' : 'Officer can edit report prior to signing'}
          </span>
        </div>

        <div className="mt-3">
          <textarea
            rows={5}
            value={panchnamaDraft}
            onChange={(e) => setPanchnamaDraft(e.target.value)}
            disabled={isAlreadyApproved}
            className="w-full p-3 bg-slate-50 border border-slate-300 rounded-lg text-xs leading-relaxed text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:bg-white font-sans"
          />
        </div>

        {/* Digital Signature / Seal Mock */}
        <div className="mt-3 p-3 bg-slate-50 rounded-lg border border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center shrink-0">
              <Stamp className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 block">
                {currentOfficer.name} ({currentOfficer.designation})
              </span>
              <span className="text-slate-500 text-[11px]">
                {currentOfficer.tehsil}, {currentOfficer.district} • ई-हस्ताक्षर अधिकृत
              </span>
            </div>
          </div>

          <div className="text-right font-mono text-[11px] text-slate-500">
            <span>डिजिटल मोहर: </span>
            <span className="text-emerald-700 font-bold">
              {app.decision?.digitalSignatureHash || 'REV-UP-2026-CERT-VALID'}
            </span>
          </div>
        </div>
      </div>

      {/* Decision Panel (Worker Always Makes the Final Call) */}
      {!isAlreadyApproved ? (
        <div className="bg-slate-50 rounded-xl border border-slate-300 p-4 shadow-sm">
          <h4 className="font-bold text-slate-900 text-sm mb-1 flex items-center gap-1.5">
            <FileCheck className="w-4 h-4 text-emerald-700" />
            <span>{isHindi ? 'अंतिम अधिकारी निर्णय (The Worker Makes the Final Call):' : 'Officer Final Decision:'}</span>
          </h4>
          <p className="text-xs text-slate-600 mb-4">
            {isHindi 
              ? 'समस्त साक्ष्यों, मौका मुआयना व पंचनामा के आधार पर निम्न में से एक कार्यवाही चुनें:' 
              : 'Choose the legal action based on field evidence and panchnama:'}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* 1. Approve Button */}
            <button
              onClick={handleApproveAction}
              className="flex flex-col items-center justify-center p-4 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold shadow-md transition-all text-center gap-1.5"
            >
              <CheckCircle2 className="w-6 h-6 text-emerald-200" />
              <span className="text-sm">{isHindi ? 'स्वीकृत करें (Approve)' : 'Approve & Sanction'}</span>
              <span className="text-[11px] text-emerald-100 font-normal">
                ₹{sanctionAmount.toLocaleString('en-IN')} {isHindi ? 'डीबीटी आदेश जारी करें' : 'Release grant'}
              </span>
            </button>

            {/* 2. Return Button */}
            <button
              onClick={() => setShowReturnBox(!showReturnBox)}
              className="flex flex-col items-center justify-center p-4 rounded-xl bg-orange-100 hover:bg-orange-200 text-orange-900 font-bold border border-orange-300 transition-all text-center gap-1.5"
            >
              <RotateCcw className="w-6 h-6 text-orange-700" />
              <span className="text-sm">{isHindi ? 'संशोधन हेतु वापस करें' : 'Return to Citizen'}</span>
              <span className="text-[11px] text-orange-700 font-normal">
                {isHindi ? 'कागजात/एनओसी सुधार नोटिस' : 'Missing document notice'}
              </span>
            </button>

            {/* 3. Reject Button */}
            <button
              onClick={() => setShowRejectBox(!showRejectBox)}
              className="flex flex-col items-center justify-center p-4 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-900 font-bold border border-rose-300 transition-all text-center gap-1.5"
            >
              <XCircle className="w-6 h-6 text-rose-700" />
              <span className="text-sm">{isHindi ? 'अस्वीकार करें (Reject)' : 'Reject Application'}</span>
              <span className="text-[11px] text-rose-700 font-normal">
                {isHindi ? 'कारण सहित विधिसम्मत आदेश' : 'Reasoned rejection order'}
              </span>
            </button>
          </div>

          {/* Return Box Drawer */}
          {showReturnBox && (
            <div className="mt-4 p-3 bg-white rounded-lg border border-orange-200 text-xs space-y-2">
              <label className="font-bold text-orange-950 block">
                {isHindi ? 'कृषक को भेजी जाने वाली आपत्ति टिप्पणी (SMS Notice):' : 'Return Remarks for SMS:'}
              </label>
              <textarea
                rows={2}
                value={returnRemarks}
                onChange={(e) => setReturnRemarks(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-xs"
              />
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowReturnBox(false)}
                  className="px-3 py-1 bg-slate-200 text-slate-700 rounded font-medium"
                >
                  {isHindi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  onClick={handleConfirmReturn}
                  className="px-4 py-1 bg-orange-700 text-white rounded font-bold"
                >
                  {isHindi ? 'संशोधन हेतु प्रेषित करें' : 'Confirm Return'}
                </button>
              </div>
            </div>
          )}

          {/* Reject Box Drawer */}
          {showRejectBox && (
            <div className="mt-4 p-3 bg-white rounded-lg border border-rose-200 text-xs space-y-2">
              <label className="font-bold text-rose-950 block">
                {isHindi ? 'अस्वीकृति का विधिक आधार व नियम संदर्भ (Statutory Ground):' : 'Rejection Ground:'}
              </label>
              <textarea
                rows={2}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-xs"
              />
              <div className="flex items-center gap-2">
                <span className="text-slate-500">{isHindi ? 'नियम संदर्भ:' : 'Rule Citation:'}</span>
                <input
                  type="text"
                  value={rejectionRule}
                  onChange={(e) => setRejectionRule(e.target.value)}
                  className="flex-1 p-1 bg-slate-50 border border-slate-300 rounded text-xs font-mono"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowRejectBox(false)}
                  className="px-3 py-1 bg-slate-200 text-slate-700 rounded font-medium"
                >
                  {isHindi ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  onClick={handleConfirmReject}
                  className="px-4 py-1 bg-rose-700 text-white rounded font-bold"
                >
                  {isHindi ? 'अस्वीकृति आदेश जारी करें' : 'Confirm Rejection'}
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Approved Status Display with Printable Certificate Button */
        <div className="bg-emerald-50 rounded-xl border border-emerald-300 p-5 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <div>
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wide bg-emerald-200 px-2 py-0.5 rounded">
                {isHindi ? 'संस्वीकृत व डीबीटी आदेश निर्गत' : 'Sanction Order Released'}
              </span>
              <h4 className="text-lg font-bold text-emerald-950 mt-1">
                {isHindi ? 'राहत राशि ₹' : 'Relief Amount ₹'}
                {app.decision?.sanctionAmount?.toLocaleString('en-IN')}/- {isHindi ? 'संस्वीकृत' : 'Sanctioned'}
              </h4>
              <p className="text-xs text-emerald-800 mt-0.5">
                {isHindi ? 'अनुमोदनकर्ता: ' : 'Approved by: '} {app.decision?.decidedBy || 'तहसीलदार (सदर)'} • {new Date(app.decision?.decidedAt || '').toLocaleDateString('hi-IN')}
              </p>
            </div>
          </div>

          <button
            onClick={() => onViewSanctionCertificate && onViewSanctionCertificate(app)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold shadow-md transition-all"
          >
            <Printer className="w-4 h-4 text-amber-300" />
            <span>{isHindi ? 'राजकीय स्वीकृति आदेश पत्र देखें / प्रिंट करें' : 'View / Print Sanction Order'}</span>
          </button>
        </div>
      )}

      {/* Back to Field Button */}
      <div className="pt-3 border-t border-slate-200 flex justify-start">
        <button
          onClick={onBackToField}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isHindi ? 'चरण 2 (मौका मुआयना) पर वापस' : 'Back to Step 2'}</span>
        </button>
      </div>
    </div>
  );
};
