import React from 'react';
import { 
  Building2, 
  ShieldCheck, 
  UserCheck, 
  Smartphone, 
  Languages, 
  Bot, 
  Download, 
  PlusCircle, 
  BookOpen,
  FileText
} from 'lucide-react';
import { OfficerProfile } from '../types/workflow';

interface NavbarProps {
  currentOfficer: OfficerProfile;
  onSwitchOfficer: (role: 'LEKHPAL' | 'TEHSILDAR' | 'CITIZEN_VIEW') => void;
  isFieldMode: boolean;
  onToggleFieldMode: () => void;
  isHindi: boolean;
  onToggleLanguage: () => void;
  onOpenAssistant: () => void;
  onOpenDocs: () => void;
  onOpenNewApp: () => void;
  onDownloadZip: () => void;
  isDownloadingZip: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentOfficer,
  onSwitchOfficer,
  isFieldMode,
  onToggleFieldMode,
  isHindi,
  onToggleLanguage,
  onOpenAssistant,
  onOpenDocs,
  onOpenNewApp,
  onDownloadZip,
  isDownloadingZip
}) => {
  return (
    <header className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white shadow-lg sticky top-0 z-40 border-b border-emerald-700/50">
      {/* Top micro-bar for Government branding */}
      <div className="bg-black/25 px-4 py-1 text-xs flex justify-between items-center text-emerald-200 border-b border-white/10">
        <div className="flex items-center space-x-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>
            {isHindi 
              ? 'राजस्व एवं आपदा प्रबंधन विभाग • उत्तर प्रदेश / भारत सरकार' 
              : 'Dept. of Revenue & Disaster Management • Govt. of India'}
          </span>
          <span className="text-white/40">|</span>
          <span className="hidden sm:inline text-amber-300 font-medium">
            {isHindi ? 'सत्यमेव जयते' : 'Satyameva Jayate'}
          </span>
        </div>
        <div className="flex items-center space-x-3 text-xs">
          <span className="text-emerald-300 hidden md:inline">
            {isHindi ? 'हल्का नंबर:' : 'Halka No:'} <strong className="text-white">{currentOfficer.halkaNumber}</strong>
          </span>
          <span className="text-white/40 hidden md:inline">|</span>
          <span className="text-emerald-300 hidden md:inline">
            {isHindi ? 'तहसील:' : 'Tehsil:'} <strong className="text-white">{currentOfficer.tehsil}</strong>
          </span>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-lg bg-emerald-700/70 border border-emerald-400/40 flex items-center justify-center shadow-md text-amber-300">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-1.5">
                  <span>{isHindi ? 'ग्राम सारथी' : 'Gram Saarathi'}</span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                    {isHindi ? 'राजस्व कार्यप्रवाह' : 'Revenue Workflow'}
                  </span>
                </h1>
              </div>
              <p className="text-xs text-emerald-200/90 hidden sm:block">
                {isHindi 
                  ? 'फसल क्षति राहत, खतौनी सत्यापन व मौका मुआयना फील्ड पोर्टल' 
                  : 'Crop Damage Relief, Land Record Scrutiny & Field Inspection Portal'}
              </p>
            </div>
          </div>

          {/* Action buttons & Officer Profile */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* New Application Button */}
            <button
              onClick={onOpenNewApp}
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-medium shadow-sm transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{isHindi ? '+ नया आवेदन' : '+ New Claim'}</span>
            </button>

            {/* AI Assistant Button */}
            <button
              onClick={onOpenAssistant}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-700/80 hover:bg-indigo-600 text-white text-xs sm:text-sm font-medium shadow-sm border border-indigo-400/30 transition-all"
              title={isHindi ? 'राजस्व एआई सहायक' : 'AI Revenue Assistant'}
            >
              <Bot className="w-4 h-4 text-amber-300" />
              <span className="hidden sm:inline">{isHindi ? 'एआई सहायक' : 'AI Assistant'}</span>
            </button>

            {/* Field Mode Toggle for tablet/sunlight */}
            <button
              onClick={onToggleFieldMode}
              className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                isFieldMode 
                  ? 'bg-amber-400 text-slate-950 border-amber-300 font-bold shadow-md' 
                  : 'bg-emerald-800/60 text-emerald-100 border-emerald-600/60 hover:bg-emerald-700/70'
              }`}
              title={isHindi ? 'धूप में पढ़ने हेतु उच्च कंट्रास्ट फील्ड मोड' : 'High-contrast Field Mode'}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">{isHindi ? 'फील्ड मोड' : 'Field Mode'}</span>
            </button>

            {/* Language Switcher */}
            <button
              onClick={onToggleLanguage}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/80 text-slate-100 hover:bg-slate-700 text-xs font-medium border border-slate-600"
              title="Toggle Language (हिंदी / English)"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-300" />
              <span>{isHindi ? 'English' : 'हिंदी'}</span>
            </button>

            {/* Documentation & Running Guide */}
            <button
              onClick={onOpenDocs}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-800/60 hover:bg-emerald-700/80 text-emerald-100 text-xs font-medium border border-emerald-600/50"
              title={isHindi ? 'प्रोजेक्ट दस्तावेज़ व मूल्यांकन विवरण' : 'Project Docs & Evaluation Guide'}
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-300" />
              <span className="hidden xl:inline">{isHindi ? 'दस्तावेज़' : 'Docs'}</span>
            </button>

            {/* Download Project ZIP */}
            <button
              onClick={onDownloadZip}
              disabled={isDownloadingZip}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-md transition-all disabled:opacity-50"
              title={isHindi ? 'परियोजना का पूर्ण ZIP डाउनलोड करें' : 'Download Full Project ZIP'}
            >
              <Download className={`w-3.5 h-3.5 ${isDownloadingZip ? 'animate-bounce' : ''}`} />
              <span className="hidden sm:inline">
                {isDownloadingZip 
                  ? (isHindi ? 'ज़िप बन रहा है...' : 'Zipping...') 
                  : (isHindi ? 'प्रोजेक्ट ZIP' : 'Project ZIP')}
              </span>
            </button>

            {/* Officer Switcher */}
            <div className="relative pl-1 sm:pl-2 border-l border-emerald-700/60">
              <select
                aria-label={isHindi ? 'अधिकारी पद बदलें' : 'Switch officer role'}
                value={currentOfficer.role}
                onChange={(e) => onSwitchOfficer(e.target.value as any)}
                className="bg-emerald-950/90 text-white text-xs font-medium rounded-lg px-2.5 py-1.5 border border-emerald-500/50 focus:outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer"
              >
                <option value="LEKHPAL">
                  {isHindi ? 'राजेश त्रिपाठी (लेखपाल/पटवारी)' : 'Rajesh Tripathi (Lekhpal)'}
                </option>
                <option value="TEHSILDAR">
                  {isHindi ? 'सुनील वर्मा (तहसीलदार - अनुमोदन)' : 'Sunil Verma (Tehsildar)'}
                </option>
                <option value="CITIZEN_VIEW">
                  {isHindi ? 'नागरिक दृश्य (Citizen Tracker)' : 'Citizen Tracker View'}
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
