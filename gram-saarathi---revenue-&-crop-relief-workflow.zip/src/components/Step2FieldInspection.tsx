import React, { useState } from 'react';
import { 
  MapPin, 
  Camera, 
  Sparkles, 
  Mic, 
  MicOff, 
  Users, 
  Plus, 
  Trash2, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft,
  Calendar,
  CloudHail,
  Wheat,
  Compass
} from 'lucide-react';
import { ReliefApplication, Witness } from '../types/workflow';
import { fieldAssessmentAI } from '../services/aiService';

interface Step2FieldInspectionProps {
  app: ReliefApplication;
  isHindi: boolean;
  onAdvanceToDecision: (updatedApp: ReliefApplication, inspectionRemarks: string) => void;
  onBackToScrutiny: () => void;
}

export const Step2FieldInspection: React.FC<Step2FieldInspectionProps> = ({
  app,
  isHindi,
  onAdvanceToDecision,
  onBackToScrutiny,
}) => {
  const existing = app.fieldInspection;

  // Form states
  const [damagePercentage, setDamagePercentage] = useState<number>(
    existing?.assessedDamagePercentage || 65
  );
  const [damageReason, setDamageReason] = useState<string>(
    existing?.damageReason || 'ओलावृष्टि एवं असामयिक भारी वर्षा'
  );
  const [weatherEventDate, setWeatherEventDate] = useState<string>(
    existing?.weatherEventDate || '2026-10-30'
  );
  const [gpsCoordinates, setGpsCoordinates] = useState<string>(
    existing?.gpsCoordinates || '26.8492° N, 80.9481° E'
  );
  const [gpsAccuracy, setGpsAccuracy] = useState<number>(
    existing?.gpsAccuracyMeters || 3.8
  );
  const [isFetchingGps, setIsFetchingGps] = useState(false);
  const [cropNotes, setCropNotes] = useState<string>(
    existing?.cropConditionNotes ||
      'खेत पर पहुंचकर पंचों की उपस्थिति में निरीक्षण किया गया। फसल का तना टूटकर गिर गया है तथा बालियां बिखर गई हैं।'
  );
  const [photoUrl, setPhotoUrl] = useState<string>(
    existing?.cropPhotoUrl ||
      'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=700&auto=format&fit=crop&q=80'
  );
  const [witnesses, setWitnesses] = useState<Witness[]>(
    existing?.witnesses || [
      { name: 'श्री जगदीश वर्मा', designation: 'ग्राम प्रधान / पंच', phone: '9415012345' },
      { name: 'श्री रामसेवक पाल', designation: 'पड़ोसी काश्तकार', phone: '9838054321' },
    ]
  );

  // New witness form
  const [newWitnessName, setNewWitnessName] = useState('');
  const [newWitnessRole, setNewWitnessRole] = useState('ग्राम पंच');

  // AI assessment state
  const [isAssessingAI, setIsAssessingAI] = useState(false);
  const [currentApp, setCurrentApp] = useState<ReliefApplication>(app);

  // Voice note simulation state
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState<string>(
    existing?.voiceNotesTranscript || ''
  );

  const fetchLiveGps = () => {
    setIsFetchingGps(true);
    setTimeout(() => {
      // Simulate realistic UP/North India revenue block coordinates with high GPS accuracy
      const lat = (26.845 + Math.random() * 0.01).toFixed(4);
      const lng = (80.945 + Math.random() * 0.01).toFixed(4);
      setGpsCoordinates(`${lat}° N, ${lng}° E`);
      setGpsAccuracy(3.2);
      setIsFetchingGps(false);
    }, 800);
  };

  const handleAddWitness = () => {
    if (!newWitnessName.trim()) return;
    setWitnesses([...witnesses, { name: newWitnessName.trim(), designation: newWitnessRole }]);
    setNewWitnessName('');
  };

  const handleRemoveWitness = (idx: number) => {
    setWitnesses(witnesses.filter((_, i) => i !== idx));
  };

  const handleSimulateVoiceDictation = () => {
    if (isRecordingVoice) {
      setIsRecordingVoice(false);
      return;
    }

    setIsRecordingVoice(true);
    setTimeout(() => {
      const dictatedText = `दिनांक को मौका मुआयना किया गया। खसरा संख्या ${currentApp.landDetails.khasraNumber} पर बोई गई ${currentApp.landDetails.cropType} फसल लगभग ${damagePercentage}% नष्ट पाई गई। पंचों के समक्ष स्थिति का आकलन कर पंचनामा दर्ज किया गया।`;
      setVoiceTranscript(dictatedText);
      setCropNotes(prev => (prev ? `${prev}\n\n[ध्वनि टिप्पणी]: ${dictatedText}` : dictatedText));
      setIsRecordingVoice(false);
    }, 2200);
  };

  const handleRunAIAssessment = async () => {
    setIsAssessingAI(true);
    try {
      const result = await fieldAssessmentAI(
        {
          cropName: currentApp.landDetails.cropType,
          khasraNo: currentApp.landDetails.khasraNumber,
        },
        cropNotes,
        damageReason,
        damagePercentage,
        gpsCoordinates
      );

      if (result.success && result.assessment) {
        const updated = {
          ...currentApp,
          fieldInspection: {
            inspectionDate: new Date().toISOString(),
            inspectorName: 'राजेश कुमार त्रिपाठी',
            inspectorDesignation: 'लेखपाल (हल्का नं 14)',
            gpsCoordinates,
            gpsAccuracyMeters: gpsAccuracy,
            damageReason,
            weatherEventDate,
            assessedDamagePercentage: result.assessment.assessedDamagePercentage,
            cropConditionNotes: cropNotes,
            cropPhotoUrl: photoUrl,
            witnesses,
            voiceNotesTranscript: voiceTranscript,
          },
          aiAnalyses: {
            ...currentApp.aiAnalyses,
            step2Field: {
              step: 'STEP2_FIELD' as const,
              generatedAt: new Date().toISOString(),
              summary: `${result.assessment.cropConditionSummary} (प्रमाणित क्षति: ${result.assessment.assessedDamagePercentage}%)`,
              confidenceScore: result.assessment.confidenceScore || 90,
              flags: result.assessment.sdrfNormsMet ? ['SDRF 33% मानक पूर्ण'] : ['33% से कम क्षति'],
              recommendation: result.assessment.recommendedReliefScale,
              data: result.assessment,
            },
          },
        };
        setDamagePercentage(result.assessment.assessedDamagePercentage);
        setCurrentApp(updated);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAssessingAI(false);
    }
  };

  const handleAdvance = () => {
    const updatedInspection = {
      inspectionDate: new Date().toISOString(),
      inspectorName: 'राजेश कुमार त्रिपाठी',
      inspectorDesignation: 'लेखपाल (हल्का नं 14)',
      gpsCoordinates,
      gpsAccuracyMeters: gpsAccuracy,
      damageReason,
      weatherEventDate,
      assessedDamagePercentage: damagePercentage,
      cropConditionNotes: cropNotes,
      cropPhotoUrl: photoUrl,
      witnesses,
      voiceNotesTranscript: voiceTranscript,
    };

    const updated = {
      ...currentApp,
      fieldInspection: updatedInspection,
    };

    onAdvanceToDecision(updated, cropNotes);
  };

  const isSdrfEligible = damagePercentage >= 33;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-sky-50 border border-sky-200 rounded-xl p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <span className="text-xs font-bold text-sky-800 uppercase tracking-wider bg-sky-200/70 px-2 py-0.5 rounded">
            {isHindi ? 'चरण 2 / 3: मौका मुआयना' : 'Step 2 of 3: Field Inspection'}
          </span>
          <h3 className="text-lg font-bold text-slate-900 mt-1">
            {isHindi 
              ? 'स्थलीय निरीक्षण, जीपीएस सत्यापन व फसल क्षति निर्धारण' 
              : 'On-Site Field Inspection, GPS Sanity & Crop Loss Assessment'}
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            {isHindi 
              ? 'खेत पर पहुंचकर पंचों के समक्ष फसल स्थिति, जीपीएस लोकेशन व क्षति प्रतिशत दर्ज करें।' 
              : 'Record on-site damage percentage with GPS coordinates, photos, and village witnesses.'}
          </p>
        </div>

        {/* AI Field Analysis Button */}
        <button
          onClick={handleRunAIAssessment}
          disabled={isAssessingAI}
          className="shrink-0 inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-700 hover:bg-indigo-600 text-white text-xs sm:text-sm font-semibold shadow-md border border-indigo-500/30 transition-all disabled:opacity-50"
        >
          <Sparkles className={`w-4 h-4 text-amber-300 ${isAssessingAI ? 'animate-spin' : ''}`} />
          <span>
            {isAssessingAI 
              ? (isHindi ? 'एआई विश्लेषण जारी...' : 'AI Analyzing Field...') 
              : (isHindi ? '⚡ एआई फसल क्षति व जीपीएस जांच' : '⚡ Run AI Crop Analysis')}
          </span>
        </button>
      </div>

      {/* Main Field Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: GPS, Weather & Photos (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* GPS Coordinates Capture Box */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-sky-600" />
                <span>{isHindi ? 'जियो-टैगिंग एवं जीपीएस निर्देशांक' : 'Geo-Tagging & GPS Fix'}</span>
              </span>
              <button
                type="button"
                onClick={fetchLiveGps}
                disabled={isFetchingGps}
                className="text-[11px] font-semibold text-sky-700 hover:text-sky-800 bg-sky-50 px-2 py-1 rounded border border-sky-200 flex items-center gap-1"
              >
                <Compass className={`w-3 h-3 ${isFetchingGps ? 'animate-spin' : ''}`} />
                <span>{isFetchingGps ? (isHindi ? 'सर्च जारी...' : 'Fixing...') : (isHindi ? 'जीपीएस रिफ्रेश' : 'Refresh GPS')}</span>
              </button>
            </div>

            <div className="mt-3 bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">{isHindi ? 'वर्तमान स्थिति:' : 'Coordinates:'}</span>
                <span className="font-mono font-bold text-slate-900">{gpsCoordinates}</span>
              </div>
              <div className="flex justify-between items-center mt-1 text-[11px]">
                <span className="text-slate-500">{isHindi ? 'जीपीएस सटीकता:' : 'Accuracy:'}</span>
                <span className="text-emerald-700 font-semibold">± {gpsAccuracy} {isHindi ? 'मीटर (सटीक)' : 'meters'}</span>
              </div>
              <div className="flex justify-between items-center mt-1 text-[11px]">
                <span className="text-slate-500">{isHindi ? 'राजस्व सीमा:' : 'Panchayat Match:'}</span>
                <span className="text-emerald-700 font-semibold">
                  {isHindi ? `ग्रा.पं. ${currentApp.applicant.gramPanchayat} सीमा अंतर्गत` : 'Inside GP boundary'}
                </span>
              </div>
            </div>
          </div>

          {/* Disaster Event Parameters */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm space-y-3 text-xs">
            <h4 className="font-bold text-slate-800 flex items-center gap-1.5 pb-2 border-b border-slate-100">
              <CloudHail className="w-4 h-4 text-amber-600" />
              <span>{isHindi ? 'आपदा एवं मौसम विवरण' : 'Disaster Parameters'}</span>
            </h4>

            <div>
              <label className="block text-slate-600 font-medium mb-1">
                {isHindi ? 'आपदा का प्रकार (Nature of Disaster):' : 'Disaster Nature:'}
              </label>
              <select
                value={damageReason}
                onChange={(e) => setDamageReason(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                <option value="ओलावृष्टि एवं असामयिक भारी वर्षा">{isHindi ? 'ओलावृष्टि एवं भारी वर्षा' : 'Hailstorm & Heavy Rain'}</option>
                <option value="अतिवृष्टि एवं खेत में जलभराव (Waterlogging)">{isHindi ? 'अतिवृष्टि एवं जलभराव' : 'Excess Rain & Waterlogging'}</option>
                <option value="तीव्र आंधी एवं फसल गिरना (Lodging)">{isHindi ? 'तीव्र आंधी एवं फसल गिरना' : 'Storm & Crop Lodging'}</option>
                <option value="सूखा एवं वर्षा की कमी">{isHindi ? 'सूखा एवं वर्षा की कमी' : 'Drought / Deficit Rain'}</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-600 font-medium mb-1">
                {isHindi ? 'आपदा घटित होने की तिथि:' : 'Weather Event Date:'}
              </label>
              <input
                type="date"
                value={weatherEventDate}
                onChange={(e) => setWeatherEventDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
          </div>

          {/* Photo with Geo-tagging Watermark */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-emerald-600" />
                <span>{isHindi ? 'मौका मुआयना जियो-टैग्ड फोटो' : 'Geotagged Inspection Photo'}</span>
              </span>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-semibold">
                {isHindi ? 'स्थान सत्यापित' : 'Geo-verified'}
              </span>
            </div>

            <div className="mt-3 relative rounded-lg overflow-hidden border border-slate-300 group">
              <img
                src={photoUrl}
                alt="Crop Damage Field"
                className="w-full h-44 object-cover object-center"
              />
              {/* Geotag & Time Watermark on Image */}
              <div className="absolute bottom-0 inset-x-0 bg-black/75 text-white p-2 text-[10px] font-mono leading-tight">
                <div className="flex justify-between items-center text-amber-300 font-bold">
                  <span>{gpsCoordinates}</span>
                  <span>± {gpsAccuracy}m</span>
                </div>
                <div className="flex justify-between items-center text-slate-300 mt-0.5">
                  <span>खसरा: {currentApp.landDetails.khasraNumber} • {currentApp.landDetails.cropType}</span>
                  <span>{new Date().toISOString().split('T')[0]}</span>
                </div>
                <div className="text-[9px] text-slate-400 mt-0.5">
                  हल्का 14 • राजस्व निरीक्षक / लेखपाल मुआयना
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Damage % Slider, Witnesses, Voice Note (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Damage Percentage Slider & SDRF Norm check */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h4 className="font-bold text-slate-900 text-sm">
                  {isHindi ? 'फसल क्षति प्रतिशत (Assessed Damage %)' : 'Assessed Damage Percentage'}
                </h4>
                <p className="text-xs text-slate-500">
                  {isHindi ? 'एसडीआरएफ नियमों के अनुसार न्यूनतम 33% क्षति आवश्यक है' : 'SDRF rules mandate at least 33% loss for relief'}
                </p>
              </div>

              <div className="text-right">
                <span className={`text-2xl font-black ${isSdrfEligible ? 'text-emerald-700' : 'text-rose-600'}`}>
                  {damagePercentage}%
                </span>
              </div>
            </div>

            {/* Slider */}
            <div className="mt-4 px-1">
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={damagePercentage}
                onChange={(e) => setDamagePercentage(parseInt(e.target.value, 10))}
                className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-700"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-bold mt-1">
                <span>0% (शून्य)</span>
                <span className="text-amber-600">33% (SDRF मानक सीमा)</span>
                <span className="text-rose-600">70% (गंभीर क्षति)</span>
                <span>100% (पूर्ण नष्ट)</span>
              </div>
            </div>

            {/* SDRF Rule Status Banner */}
            <div className={`mt-3 p-2.5 rounded-lg border text-xs flex items-center justify-between ${
              isSdrfEligible 
                ? 'bg-emerald-50 border-emerald-300 text-emerald-900' 
                : 'bg-rose-50 border-rose-300 text-rose-900'
            }`}>
              <div className="flex items-center gap-2">
                {isSdrfEligible ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                )}
                <span>
                  {isSdrfEligible
                    ? (isHindi 
                        ? 'पात्रता पुष्ट: फसल क्षति 33% से अधिक है। SDRF इनपुट सब्सिडी अनुमन्य होगी।' 
                        : 'Eligible: Damage is ≥ 33%. Relief subsidy admissible under SDRF.')
                    : (isHindi 
                        ? 'अपात्र चेतावनी: 33% से कम क्षति होने पर व्यक्तिगत दावा स्वीकार्य नहीं है।' 
                        : 'Warning: Under SDRF norms, damage < 33% is not admissible for individual cash relief.')}
                </span>
              </div>
              <span className="font-bold text-[11px] px-2 py-0.5 rounded bg-white/80 shrink-0">
                {damagePercentage >= 70 ? (isHindi ? 'गंभीर क्षति' : 'Severe') : isSdrfEligible ? (isHindi ? 'मानक पूर्ण' : 'Eligible') : (isHindi ? 'अपात्र' : 'Ineligible')}
              </span>
            </div>
          </div>

          {/* Village Witnesses (पंच) */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-700" />
                <span>{isHindi ? 'मौका मुआयना उपस्थित पंच / गवाह (Witnesses)' : 'Panchayat Witnesses'}</span>
              </h4>
              <span className="text-xs text-slate-500">
                {witnesses.length} {isHindi ? 'पंच उपस्थित' : 'witnesses'}
              </span>
            </div>

            <div className="mt-3 space-y-2">
              {witnesses.map((w, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                  <div>
                    <span className="font-bold text-slate-800">{w.name}</span>
                    <span className="text-slate-500 ml-2">({w.designation})</span>
                    {w.phone && <span className="text-slate-400 ml-2 font-mono">{w.phone}</span>}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveWitness(idx)}
                    className="text-slate-400 hover:text-rose-600 p-1"
                    title={isHindi ? 'हटाएं' : 'Remove'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add witness row */}
            <div className="mt-3 pt-2 border-t border-slate-100 flex items-center gap-2">
              <input
                type="text"
                placeholder={isHindi ? 'पंच का नाम (उदा. श्री रामप्रसाद)...' : 'Witness Name...'}
                value={newWitnessName}
                onChange={(e) => setNewWitnessName(e.target.value)}
                className="flex-1 p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
              <select
                value={newWitnessRole}
                onChange={(e) => setNewWitnessRole(e.target.value)}
                className="p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-700"
              >
                <option value="ग्राम पंच">{isHindi ? 'ग्राम पंच' : 'Gram Panch'}</option>
                <option value="पड़ोसी काश्तकार">{isHindi ? 'पड़ोसी काश्तकार' : 'Neighboring Farmer'}</option>
                <option value="ग्राम प्रधान">{isHindi ? 'ग्राम प्रधान' : 'Gram Pradhan'}</option>
                <option value="क्षेत्र पंचायत सदस्य (BDC)">{isHindi ? 'क्षेत्र पंचायत सदस्य' : 'BDC Member'}</option>
              </select>
              <button
                type="button"
                onClick={handleAddWitness}
                className="px-3 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isHindi ? 'जोड़ें' : 'Add'}</span>
              </button>
            </div>
          </div>

          {/* Hindi Voice Note Dictation & Notes */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <span>{isHindi ? 'स्थलीय निरीक्षण आख्या टिप्पणी:' : 'Inspection Notes:'}</span>
              </label>

              {/* Voice button */}
              <button
                type="button"
                onClick={handleSimulateVoiceDictation}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  isRecordingVoice 
                    ? 'bg-rose-600 text-white animate-pulse' 
                    : 'bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100'
                }`}
                title={isHindi ? 'हिंदी में बोलकर टिप्पणी दर्ज करें' : 'Dictate Hindi Voice Note'}
              >
                {isRecordingVoice ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                <span>
                  {isRecordingVoice 
                    ? (isHindi ? 'सुन रहा है... (बोलिए)' : 'Recording...') 
                    : (isHindi ? '🎙️ बोलकर लिखें' : 'Voice Dictate')}
                </span>
              </button>
            </div>

            <textarea
              rows={3}
              value={cropNotes}
              onChange={(e) => setCropNotes(e.target.value)}
              placeholder={isHindi ? 'खेत की वास्तविक स्थिति, फसल क्षति का कारण, पंचों के बयान दर्ज करें...' : 'Enter ground observation notes...'}
              className="w-full mt-2 p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white"
            />
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
        <button
          onClick={onBackToScrutiny}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isHindi ? 'चरण 1 (दस्तावेज़) पर वापस' : 'Back to Step 1'}</span>
        </button>

        <button
          onClick={handleAdvance}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs sm:text-sm font-bold shadow-md transition-all"
        >
          <span>{isHindi ? 'मौका मुआयना पूर्ण ➔ चरण 3: संस्तुति व पंचनामा तैयार करें' : 'Inspection Complete ➔ Advance to Step 3: Sanction'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
