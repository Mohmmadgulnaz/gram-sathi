import React from 'react';
import { X, Printer, Building2, CheckCircle2, ShieldCheck, QrCode } from 'lucide-react';
import { ReliefApplication } from '../types/workflow';

interface SanctionCertificateModalProps {
  app: ReliefApplication;
  isHindi: boolean;
  onClose: () => void;
}

export const SanctionCertificateModal: React.FC<SanctionCertificateModalProps> = ({
  app,
  isHindi,
  onClose,
}) => {
  const handlePrint = () => {
    window.print();
  };

  const amount = app.decision?.sanctionAmount || 15640;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full border border-slate-300 overflow-hidden my-6">
        {/* Top Modal Controls (Hidden in print) */}
        <div className="no-print bg-slate-900 text-white px-5 py-3 flex items-center justify-between border-b border-slate-700">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-sm sm:text-base">
              {isHindi ? 'राजकीय स्वीकृति आदेश पत्र (Official Sanction Certificate)' : 'Official Sanction Order'}
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{isHindi ? 'प्रिंट करें (Print / PDF)' : 'Print / PDF'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Official Government Order Document */}
        <div className="p-6 sm:p-10 text-slate-900 font-serif leading-relaxed bg-white">
          {/* Official Government Header */}
          <div className="text-center border-b-2 border-slate-900 pb-5">
            <div className="inline-block p-2 rounded-full bg-slate-100 text-slate-900 mb-2 border border-slate-300">
              <Building2 className="w-8 h-8 mx-auto" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight uppercase">
              {isHindi ? 'कार्यालय तहसीलदार / उपजिलाधिकारी' : 'OFFICE OF THE TEHSILDAR / SDM'}
            </h2>
            <h4 className="text-sm font-semibold text-slate-700">
              {isHindi ? 'तहसील सदर, जनपद लखनऊ, उत्तर प्रदेश शासन' : 'Tehsil Sadar, Revenue Administration'}
            </h4>
            <p className="text-xs text-slate-500 mt-1">
              राज्य आपदा मोचन निधि (SDRF) / राष्ट्रीय आपदा मोचन निधि (NDRF) अंतर्गत कृषि इनपुट सब्सिडी स्वीकृति
            </p>
          </div>

          {/* Reference & Date */}
          <div className="flex justify-between items-center text-xs font-mono my-4 pb-2 border-b border-slate-200">
            <span>
              <strong>पत्रांक:</strong> UP/REV/SDRF/2026/{app.id}/ORD
            </span>
            <span>
              <strong>दिनांक:</strong> {new Date().toLocaleDateString('hi-IN', { day: '2-digit', month: 'long', year: 'numeric' })}
            </span>
          </div>

          {/* Sanction Title */}
          <div className="text-center my-4">
            <h3 className="text-base sm:text-lg font-bold underline decoration-1 underline-offset-4 text-slate-950">
              वित्तीय एवं प्रशासनिक स्वीकृति आदेश
            </h3>
          </div>

          {/* Body Text */}
          <div className="text-xs sm:text-sm text-slate-800 space-y-3 text-justify">
            <p>
              शासन के शासनादेश संख्या <strong>412/आपदा-2024-25</strong> के अधीन अधिसूचित प्राकृतिक आपदा (ओलावृष्टि / असमय अतिवृष्टि) से क्षतिग्रस्त हुई फसलों की भरपाई हेतु प्राप्त आवेदन पत्र संख्या <strong>{app.id}</strong> के संबंध में लेखपाल एवं राजस्व निरीक्षक द्वारा संयुक्त स्थलीय मौका मुआयना आख्या व पंचनामा प्रस्तुत किया गया।
            </p>
            <p>
              आख्यानुसार प्रार्थी <strong>{app.applicant.name}</strong> आत्मज <strong>{app.applicant.fatherOrHusbandName}</strong>, निवासी ग्राम <strong>{app.applicant.village}</strong>, ग्राम पंचायत <strong>{app.applicant.gramPanchayat}</strong> के खसरा संख्या <strong>{app.landDetails.khasraNumber}</strong> में बोई गई <strong>{app.landDetails.cropType}</strong> की फसल <strong>{app.fieldInspection?.assessedDamagePercentage || 70}%</strong> क्षतिग्रस्त प्रमाणित पाई गई है।
            </p>
          </div>

          {/* Beneficiary & Sanction Details Table */}
          <div className="my-5 overflow-x-auto">
            <table className="w-full text-xs border-collapse border border-slate-300">
              <tbody>
                <tr className="bg-slate-100 font-bold">
                  <td className="border border-slate-300 p-2">लाभार्थी का नाम</td>
                  <td className="border border-slate-300 p-2">{app.applicant.name}</td>
                  <td className="border border-slate-300 p-2">आधार संख्या (अंतिम 4)</td>
                  <td className="border border-slate-300 p-2 font-mono">XXXX-XXXX-{app.applicant.aadhaarLast4}</td>
                </tr>
                <tr>
                  <td className="border border-slate-300 p-2 font-semibold">खसरा / खतौनी संख्या</td>
                  <td className="border border-slate-300 p-2 font-mono">गाटा {app.landDetails.khasraNumber} (खाता {app.landDetails.khatauniNumber})</td>
                  <td className="border border-slate-300 p-2 font-semibold">सत्यापित रकबा</td>
                  <td className="border border-slate-300 p-2">{app.landDetails.claimedAreaHectare} हेक्टेयर ({app.landDetails.irrigationType})</td>
                </tr>
                <tr>
                  <td className="border border-slate-300 p-2 font-semibold">फसल व क्षति %</td>
                  <td className="border border-slate-300 p-2">{app.landDetails.cropType} ({app.fieldInspection?.assessedDamagePercentage || 65}% क्षति)</td>
                  <td className="border border-slate-300 p-2 font-semibold">मानक सहायता दर</td>
                  <td className="border border-slate-300 p-2">₹17,000/- प्रति हेक्टेयर</td>
                </tr>
                <tr className="bg-emerald-50 font-bold">
                  <td className="border border-slate-300 p-2 text-emerald-950">स्वीकृत कुल राहत अनुदान</td>
                  <td className="border border-slate-300 p-2 text-emerald-950 text-sm" colSpan={3}>
                    ₹{amount.toLocaleString('en-IN')}/- (रुपये {amount.toLocaleString('hi-IN')} मात्र)
                  </td>
                </tr>
                <tr>
                  <td className="border border-slate-300 p-2 font-semibold">भुगतान माध्यम (DBT)</td>
                  <td className="border border-slate-300 p-2 font-mono" colSpan={3}>
                    खाता: {app.applicant.bankAccount} • {app.applicant.bankName} (IFSC: {app.applicant.ifsc})
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <p className="text-xs text-slate-800 text-justify">
            अतएव SDRF/NDRF नियमों के अंतर्गत उक्त धनराशि प्रार्थी के आधार सीडेड बैंक खाते में प्रत्यक्ष लाभ अंतरण (DBT) के माध्यम से कोषागार द्वारा सीधे अंतरित करने का आदेश दिया जाता है।
          </p>

          {/* Official Signatures & QR Code Footer */}
          <div className="mt-8 pt-4 border-t border-slate-300 flex items-end justify-between text-xs">
            {/* QR Code */}
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 border border-slate-300 p-1 rounded bg-slate-50 flex items-center justify-center">
                <QrCode className="w-12 h-12 text-slate-800" />
              </div>
              <div className="text-[10px] text-slate-500 font-mono leading-tight">
                <span>डिजिटल सत्यापन QR कोड</span><br />
                <span>e-District UP Portal</span><br />
                <span>सुरक्षित हैश: {app.decision?.digitalSignatureHash || 'UP-REV-DSIG-VALID'}</span>
              </div>
            </div>

            {/* Officer Digital Seal */}
            <div className="text-center space-y-1">
              <div className="inline-block px-3 py-1 bg-slate-100 border border-slate-300 rounded text-[11px] font-mono text-emerald-800 font-bold">
                ✓ Digitally Signed & Approved
              </div>
              <div className="font-bold text-slate-900 mt-1">
                सुनील कुमार वर्मा
              </div>
              <div className="text-slate-600 text-[11px]">
                तहसीलदार / उपजिलाधिकारी (सदर)
              </div>
              <div className="text-[10px] text-slate-400">
                राजस्व प्रशासन, उत्तर प्रदेश
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
