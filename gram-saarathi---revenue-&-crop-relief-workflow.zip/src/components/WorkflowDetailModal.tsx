import React, { useState } from 'react';
import { 
  X, 
  FileCheck2, 
  MapPin, 
  Clock, 
  History, 
  CheckCircle2, 
  Printer, 
  User, 
  Wheat, 
  Share2,
  Calendar,
  AlertTriangle
} from 'lucide-react';
import { ReliefApplication, OfficerProfile } from '../types/workflow';
import { Step1DocumentScrutiny } from './Step1DocumentScrutiny';
import { Step2FieldInspection } from './Step2FieldInspection';
import { Step3SanctionDecision } from './Step3SanctionDecision';
import { AuditTrailView } from './AuditTrailView';

interface WorkflowDetailModalProps {
  app: ReliefApplication;
  currentOfficer: OfficerProfile;
  isHindi: boolean;
  onClose: () => void;
  onUpdateApp: (updatedApp: ReliefApplication) => void;
  onViewSanctionCertificate: (app: ReliefApplication) => void;
}

export const WorkflowDetailModal: React.FC<WorkflowDetailModalProps> = ({
  app,
  currentOfficer,
  isHindi,
  onClose,
  onUpdateApp,
  onViewSanctionCertificate,
}) => {
  // Determine initial active tab based on application's current stage
  const getInitialTab = () => {
    switch (app.currentStage) {
      case 'SCRUTINY': return 'STEP1';
      case 'FIELD_INSPECT': return 'STEP2';
      case 'DECISION':
      case 'APPROVED':
      case 'REJECTED':
      case 'RETURNED': return 'STEP3';
      default: return 'STEP1';
    }
  };

  const [activeTab, setActiveTab] = useState<'STEP1' | 'STEP2' | 'STEP3' | 'AUDIT'>(getInitialTab());

  // Step 1 ➔ Step 2
  const handleAdvanceToField = (updatedApp: ReliefApplication, remarks: string) => {
    const newLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      stage: 'FIELD_INSPECT' as const,
      action: 'दस्तावेज़ सत्यापित व मौका मुआयना नियत',
      actionEn: 'Documents Verified & Inspection Scheduled',
      officerName: currentOfficer.name,
      officerRole: currentOfficer.designation,
      remarks,
      aiSnapshot: updatedApp.aiAnalyses.step1Docs?.summary,
    };

    const nextApp: ReliefApplication = {
      ...updatedApp,
      currentStage: 'FIELD_INSPECT',
      auditTrail: [newLog, ...updatedApp.auditTrail],
    };

    onUpdateApp(nextApp);
    setActiveTab('STEP2');
  };

  // Return to citizen from Step 1
  const handleReturnFromScrutiny = (updatedApp: ReliefApplication, reason: string) => {
    const newLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      stage: 'RETURNED' as const,
      action: 'संशोधन हेतु वापस प्रेषित (Returned to Citizen)',
      actionEn: 'Returned for Correction',
      officerName: currentOfficer.name,
      officerRole: currentOfficer.designation,
      remarks: reason,
    };

    const nextApp: ReliefApplication = {
      ...updatedApp,
      currentStage: 'RETURNED',
      decision: {
        decision: 'RETURN',
        decidedAt: new Date().toISOString(),
        decidedBy: currentOfficer.name,
        officerDesignation: currentOfficer.designation,
        returnRemarks: reason,
      },
      auditTrail: [newLog, ...updatedApp.auditTrail],
    };

    onUpdateApp(nextApp);
  };

  // Step 2 ➔ Step 3
  const handleAdvanceToDecision = (updatedApp: ReliefApplication, remarks: string) => {
    const newLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      stage: 'DECISION' as const,
      action: 'मौका मुआयना संपन्न - पंचनामा व संस्तुति अग्रेषित',
      actionEn: 'Field Inspection Completed, Forwarded for Sanction',
      officerName: currentOfficer.name,
      officerRole: currentOfficer.designation,
      remarks,
      aiSnapshot: updatedApp.aiAnalyses.step2Field?.summary,
    };

    const nextApp: ReliefApplication = {
      ...updatedApp,
      currentStage: 'DECISION',
      auditTrail: [newLog, ...updatedApp.auditTrail],
    };

    onUpdateApp(nextApp);
    setActiveTab('STEP3');
  };

  // Step 3 Actions: Approve
  const handleApprove = (updatedApp: ReliefApplication, sanctionAmount: number, panchnamaText: string) => {
    const newLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      stage: 'APPROVED' as const,
      action: 'वित्तीय एवं प्रशासनिक संस्वीकृति जारी (Sanction Order Released)',
      actionEn: 'Sanction Order Released via DBT',
      officerName: currentOfficer.name,
      officerRole: currentOfficer.designation,
      remarks: `₹${sanctionAmount.toLocaleString('en-IN')}/- की राहत राशि का भुगतान आदेश डीबीटी कोषागार को अग्रेषित।`,
    };

    const nextApp: ReliefApplication = {
      ...updatedApp,
      currentStage: 'APPROVED',
      decision: {
        decision: 'APPROVE',
        decidedAt: new Date().toISOString(),
        decidedBy: currentOfficer.name,
        officerDesignation: currentOfficer.designation,
        sanctionAmount,
        panchnamaText,
        digitalSignatureHash: `DSIG-UP-REV-2026-${app.id.slice(-4)}-${Math.random().toString(36).substring(2, 8)}`,
      },
      auditTrail: [newLog, ...updatedApp.auditTrail],
    };

    onUpdateApp(nextApp);
  };

  // Step 3 Actions: Reject
  const handleReject = (updatedApp: ReliefApplication, reason: string, ruleRef: string) => {
    const newLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      stage: 'REJECTED' as const,
      action: 'आवेदन अस्वीकृत (Application Rejected)',
      actionEn: 'Application Rejected',
      officerName: currentOfficer.name,
      officerRole: currentOfficer.designation,
      remarks: `कारण: ${reason} (नियम: ${ruleRef})`,
    };

    const nextApp: ReliefApplication = {
      ...updatedApp,
      currentStage: 'REJECTED',
      decision: {
        decision: 'REJECT',
        decidedAt: new Date().toISOString(),
        decidedBy: currentOfficer.name,
        officerDesignation: currentOfficer.designation,
        rejectionReason: reason,
        rejectionRuleRef: ruleRef,
      },
      auditTrail: [newLog, ...updatedApp.auditTrail],
    };

    onUpdateApp(nextApp);
  };

  // Step 3 Actions: Return
  const handleReturnFromDecision = (updatedApp: ReliefApplication, remarks: string, missingDocs: string[]) => {
    const newLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      stage: 'RETURNED' as const,
      action: 'संशोधन हेतु वापस प्रेषित (Returned to Citizen)',
      actionEn: 'Returned for Document Fix',
      officerName: currentOfficer.name,
      officerRole: currentOfficer.designation,
      remarks,
    };

    const nextApp: ReliefApplication = {
      ...updatedApp,
      currentStage: 'RETURNED',
      decision: {
        decision: 'RETURN',
        decidedAt: new Date().toISOString(),
        decidedBy: currentOfficer.name,
        officerDesignation: currentOfficer.designation,
        returnRemarks: remarks,
        missingDocuments: missingDocs,
      },
      auditTrail: [newLog, ...updatedApp.auditTrail],
    };

    onUpdateApp(nextApp);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full border border-slate-300 overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold">
              <Wheat className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs bg-slate-800 text-emerald-300 px-2 py-0.5 rounded font-bold">
                  {app.id}
                </span>
                <span className="text-xs bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded border border-amber-400/30 font-semibold">
                  {app.applicant.category}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white mt-0.5 flex items-center gap-2">
                <span>{app.applicant.name}</span>
                <span className="text-xs text-slate-400 font-normal">
                  ({app.applicant.fatherOrHusbandName})
                </span>
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {app.currentStage === 'APPROVED' && (
              <button
                onClick={() => onViewSanctionCertificate(app)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{isHindi ? 'स्वीकृति आदेश पत्र' : 'Sanction Certificate'}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Step Navigation Tabs */}
        <div className="bg-slate-100 border-b border-slate-200 px-4 sm:px-6 pt-2 flex items-center space-x-2 overflow-x-auto shrink-0">
          <button
            onClick={() => setActiveTab('STEP1')}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'STEP1'
                ? 'border-emerald-700 text-emerald-800 bg-white/70 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileCheck2 className="w-4 h-4 text-amber-600" />
            <span>{isHindi ? 'चरण 1: दस्तावेज़ व खतौनी' : 'Step 1: Scrutiny'}</span>
          </button>

          <button
            onClick={() => setActiveTab('STEP2')}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'STEP2'
                ? 'border-sky-600 text-sky-800 bg-white/70 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <MapPin className="w-4 h-4 text-sky-600" />
            <span>{isHindi ? 'चरण 2: मौका मुआयना' : 'Step 2: Field Inspection'}</span>
          </button>

          <button
            onClick={() => setActiveTab('STEP3')}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'STEP3'
                ? 'border-purple-600 text-purple-800 bg-white/70 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4 text-purple-600" />
            <span>{isHindi ? 'चरण 3: संस्तुति व निर्णय' : 'Step 3: Sanction'}</span>
          </button>

          <button
            onClick={() => setActiveTab('AUDIT')}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'AUDIT'
                ? 'border-slate-800 text-slate-900 bg-white/70 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-4 h-4 text-slate-600" />
            <span>{isHindi ? 'ऑडिट इतिहास' : 'Audit Trail'}</span>
            <span className="text-[10px] bg-slate-300 text-slate-800 px-1.5 py-0.2 rounded-full">
              {app.auditTrail.length}
            </span>
          </button>
        </div>

        {/* Modal Body Container */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto bg-slate-50/50">
          {activeTab === 'STEP1' && (
            <Step1DocumentScrutiny
              app={app}
              isHindi={isHindi}
              onAdvanceToField={handleAdvanceToField}
              onReturnForCorrection={handleReturnFromScrutiny}
            />
          )}

          {activeTab === 'STEP2' && (
            <Step2FieldInspection
              app={app}
              isHindi={isHindi}
              onAdvanceToDecision={handleAdvanceToDecision}
              onBackToScrutiny={() => setActiveTab('STEP1')}
            />
          )}

          {activeTab === 'STEP3' && (
            <Step3SanctionDecision
              app={app}
              currentOfficer={currentOfficer}
              isHindi={isHindi}
              onApprove={handleApprove}
              onReject={handleReject}
              onReturn={handleReturnFromDecision}
              onBackToField={() => setActiveTab('STEP2')}
              onViewSanctionCertificate={onViewSanctionCertificate}
            />
          )}

          {activeTab === 'AUDIT' && (
            <AuditTrailView logs={app.auditTrail} isHindi={isHindi} />
          )}
        </div>
      </div>
    </div>
  );
};
