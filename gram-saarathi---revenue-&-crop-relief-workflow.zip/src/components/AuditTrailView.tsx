import React from 'react';
import { Clock, User, ShieldCheck, Sparkles, FileText, CheckCircle2 } from 'lucide-react';
import { AuditLogEntry } from '../types/workflow';

interface AuditTrailViewProps {
  logs: AuditLogEntry[];
  isHindi: boolean;
}

export const AuditTrailView: React.FC<AuditTrailViewProps> = ({ logs, isHindi }) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
          <Clock className="w-4 h-4 text-emerald-700" />
          <span>{isHindi ? 'कार्यप्रवाह इतिहास एवं विधिक ऑडिट लॉग' : 'Workflow Audit Trail & History'}</span>
        </h4>
        <span className="text-xs text-slate-500 font-mono">
          {logs.length} {isHindi ? 'प्रविष्टियां' : 'records'}
        </span>
      </div>

      <div className="mt-4 relative pl-6 space-y-6 before:absolute before:inset-y-0 before:left-2.5 before:w-0.5 before:bg-slate-200">
        {logs.map((log, idx) => (
          <div key={log.id || idx} className="relative group">
            {/* Timeline bullet */}
            <div className="absolute -left-[27px] top-1 w-4 h-4 rounded-full bg-emerald-600 border-2 border-white shadow-sm flex items-center justify-center">
              <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
            </div>

            <div className="bg-slate-50 rounded-lg p-3 border border-slate-200/80 hover:border-slate-300 transition-colors text-xs">
              <div className="flex flex-wrap items-center justify-between gap-1 mb-1">
                <span className="font-bold text-slate-900 text-xs">
                  {isHindi ? log.action : log.actionEn}
                </span>
                <span className="text-[11px] font-mono text-slate-400">
                  {new Date(log.timestamp).toLocaleString(isHindi ? 'hi-IN' : 'en-US', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>

              <div className="flex items-center gap-1.5 text-slate-600 font-medium mb-1.5 text-[11px]">
                <User className="w-3 h-3 text-slate-400" />
                <span>{log.officerName}</span>
                <span className="text-slate-400">•</span>
                <span className="text-emerald-800 font-semibold">{log.officerRole}</span>
              </div>

              <p className="text-slate-700 leading-relaxed bg-white p-2 rounded border border-slate-100 text-[11px]">
                {log.remarks}
              </p>

              {log.aiSnapshot && (
                <div className="mt-2 p-1.5 bg-indigo-50/70 border border-indigo-100 rounded text-[11px] text-indigo-900 flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-amber-500 shrink-0" />
                  <span><strong>AI Snapshot:</strong> {log.aiSnapshot}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
