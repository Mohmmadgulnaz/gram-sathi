import React from 'react';
import { Search, Filter, AlertCircle } from 'lucide-react';
import { ApplicationStage, PriorityLevel } from '../types/workflow';

interface ApplicationFilterBarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedStage: string;
  onSelectStage: (stage: string) => void;
  selectedPanchayat: string;
  onSelectPanchayat: (panchayat: string) => void;
  selectedPriority: string;
  onSelectPriority: (priority: string) => void;
  isHindi: boolean;
  stageCounts: Record<string, number>;
}

export const ApplicationFilterBar: React.FC<ApplicationFilterBarProps> = ({
  searchQuery,
  onSearchChange,
  selectedStage,
  onSelectStage,
  selectedPanchayat,
  onSelectPanchayat,
  selectedPriority,
  onSelectPriority,
  isHindi,
  stageCounts,
}) => {
  const stages = [
    { key: 'ALL', labelHi: 'सभी आवेदन', labelEn: 'All Applications' },
    { key: 'SCRUTINY', labelHi: 'चरण 1: दस्तावेज़ जांच', labelEn: '1. Scrutiny' },
    { key: 'FIELD_INSPECT', labelHi: 'चरण 2: मौका मुआयना', labelEn: '2. Field Inspect' },
    { key: 'DECISION', labelHi: 'चरण 3: संस्तुति/निर्णय', labelEn: '3. Decision' },
    { key: 'APPROVED', labelHi: 'संस्वीकृत (Approved)', labelEn: 'Approved' },
    { key: 'RETURNED', labelHi: 'संशोधन हेतु वापस', labelEn: 'Returned' },
    { key: 'REJECTED', labelHi: 'अस्वीकृत', labelEn: 'Rejected' },
  ];

  const panchayats = [
    { key: 'ALL', nameHi: 'सभी ग्राम पंचायतें (All Panchayats)', nameEn: 'All Gram Panchayats' },
    { key: 'रामपुर', nameHi: 'ग्राम पंचायत रामपुर', nameEn: 'Rampur' },
    { key: 'बिजौली', nameHi: 'ग्राम पंचायत बिजौली', nameEn: 'Bijauli' },
    { key: 'कल्याणपुर', nameHi: 'ग्राम पंचायत कल्याणपुर', nameEn: 'Kalyanpur' },
    { key: 'शिवगढ़', nameHi: 'ग्राम पंचायत शिवगढ़', nameEn: 'Shivgarh' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 mb-6">
      {/* Search and Dropdowns Row */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mb-4">
        {/* Search Input */}
        <div className="relative md:col-span-5">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={
              isHindi
                ? 'कृषक का नाम, आधार (अंतिम 4), खसरा संख्या, या आवेदन क्रमांक खोजें...'
                : 'Search farmer name, Aadhaar last 4, Khasra, or App ID...'
            }
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-colors"
          />
        </div>

        {/* Panchayat Filter */}
        <div className="md:col-span-4">
          <select
            aria-label={isHindi ? 'ग्राम पंचायत चुनें' : 'Select Gram Panchayat'}
            value={selectedPanchayat}
            onChange={(e) => onSelectPanchayat(e.target.value)}
            className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            {panchayats.map((p) => (
              <option key={p.key} value={p.key}>
                {isHindi ? p.nameHi : p.nameEn}
              </option>
            ))}
          </select>
        </div>

        {/* Priority Filter */}
        <div className="md:col-span-3">
          <select
            aria-label={isHindi ? 'प्राथमिकता चुनें' : 'Select Priority Filter'}
            value={selectedPriority}
            onChange={(e) => onSelectPriority(e.target.value)}
            className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="ALL">{isHindi ? 'सभी प्राथमिकता स्तर' : 'All Priority Levels'}</option>
            <option value="URGENT">{isHindi ? '⚠️ अति आवश्यक / SLA आसन्न' : '⚠️ Urgent / SLA Nearing'}</option>
            <option value="HIGH_DAMAGE">{isHindi ? '🔥 गंभीर क्षति (>70%)' : '🔥 Severe Damage (>70%)'}</option>
            <option value="MARGINAL_FARMER">{isHindi ? '🌾 सीमान्त कृषक (<1हे.)' : '🌾 Marginal Farmers'}</option>
          </select>
        </div>
      </div>

      {/* Stage Tabs */}
      <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-thin">
        {stages.map((st) => {
          const count = stageCounts[st.key] || 0;
          const isActive = selectedStage === st.key;
          return (
            <button
              key={st.key}
              onClick={() => onSelectStage(st.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all flex items-center gap-1.5 ${
                isActive
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              <span>{isHindi ? st.labelHi : st.labelEn}</span>
              <span
                className={`text-[11px] px-1.5 py-0.2 rounded-full font-bold ${
                  isActive ? 'bg-emerald-900/60 text-white' : 'bg-slate-300 text-slate-700'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
