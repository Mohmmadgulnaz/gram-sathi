import React, { useState } from 'react';
import { X, PlusCircle, User, FileSpreadsheet, Wheat } from 'lucide-react';
import { ReliefApplication } from '../types/workflow';

interface NewApplicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  isHindi: boolean;
  onSubmit: (newApp: ReliefApplication) => void;
}

export const NewApplicationModal: React.FC<NewApplicationModalProps> = ({
  isOpen,
  onClose,
  isHindi,
  onSubmit,
}) => {
  const [name, setName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [age, setAge] = useState(45);
  const [phone, setPhone] = useState('9839000000');
  const [aadhaarLast4, setAadhaarLast4] = useState('5544');
  const [village, setVillage] = useState('रामपुर मजरा');
  const [gramPanchayat, setGramPanchayat] = useState('रामपुर');
  const [khasraNumber, setKhasraNumber] = useState('188/1');
  const [khatauniNumber, setKhatauniNumber] = useState('00215');
  const [claimedArea, setClaimedArea] = useState(0.75);
  const [cropType, setCropType] = useState('गेहूं (एच.डी. 2967)');
  const [irrigationType, setIrrigationType] = useState<'सिंचित (Irrigated)' | 'असिंचित (Rainfed)'>('सिंचित (Irrigated)');
  const [coSharersCount, setCoSharersCount] = useState(1);
  const [priority, setPriority] = useState<'NORMAL' | 'URGENT' | 'HIGH_DAMAGE'>('URGENT');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newId = `KRF-2026-UP-${Math.floor(8000 + Math.random() * 1999)}`;
    const newApp: ReliefApplication = {
      id: newId,
      submissionDate: new Date().toISOString(),
      currentStage: 'SCRUTINY',
      priority,
      slaDeadline: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString(),
      applicant: {
        id: `APP-${Date.now()}`,
        name: name.trim(),
        nameEn: name.trim(),
        fatherOrHusbandName: fatherName.trim() || 'स्व. रामस्वरूप',
        gender: 'M',
        age: Number(age),
        phone: phone.trim(),
        aadhaarLast4: aadhaarLast4.trim(),
        village: village.trim(),
        villageEn: village.trim(),
        gramPanchayat: gramPanchayat.trim(),
        gramPanchayatEn: gramPanchayat.trim(),
        category: claimedArea <= 1 ? 'सीमान्त (<1हे.)' : claimedArea <= 2 ? 'लघु (1-2हे.)' : 'सामान्य (>2हे.)',
        bankAccount: '31098877665',
        bankName: 'भारतीय स्टेट बैंक (SBI)',
        ifsc: 'SBIN0001429',
      },
      landDetails: {
        khasraNumber: khasraNumber.trim(),
        khatauniNumber: khatauniNumber.trim(),
        ownerNameInKhatauni: name.trim(),
        ownerNameInKhatauniEn: name.trim(),
        totalKhatauniAreaHectare: claimedArea * coSharersCount,
        claimedAreaHectare: Number(claimedArea),
        cropType,
        cropTypeEn: cropType,
        irrigationType,
        coSharersCount: Number(coSharersCount),
        landMutationStatus: 'अद्यतन (Updated)',
      },
      documents: [
        { title: 'आधार कार्ड प्रतिलिपि', type: 'AADHAAR', verified: true },
        { title: 'खतौनी इंतखाब नकल (2025-26)', type: 'KHATAUNI', verified: false },
        { title: 'बैंक पासबुक प्रथम पृष्ठ', type: 'BANK_PASSBOOK', verified: true },
      ],
      aiAnalyses: {},
      auditTrail: [
        {
          id: `LOG-${Date.now()}`,
          timestamp: new Date().toISOString(),
          stage: 'SCRUTINY',
          action: 'क्षेत्रीय शिविर में नवीन आवेदन पंजीकृत',
          actionEn: 'New Application Registered in Field Camp',
          officerName: 'राजेश कुमार त्रिपाठी',
          officerRole: 'लेखपाल (हल्का 14)',
          remarks: 'ग्राम शिविर में कृषक द्वारा प्राकृतिक आपदा फसल क्षति दावा पत्र प्रस्तुत किया गया।',
        },
      ],
    };

    onSubmit(newApp);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full border border-slate-300 overflow-hidden my-6">
        <div className="bg-emerald-900 text-white p-4 flex items-center justify-between border-b border-emerald-800">
          <div className="flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-amber-300" />
            <h3 className="font-bold text-base">
              {isHindi ? 'नवीन फसल क्षति राहत आवेदन दर्ज करें' : 'Register New Crop Relief Claim'}
            </h3>
          </div>
          <button onClick={onClose} className="p-1 text-white/70 hover:text-white rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          {/* Applicant Info */}
          <div className="space-y-2">
            <span className="font-bold text-slate-800 flex items-center gap-1.5 pb-1 border-b border-slate-100">
              <User className="w-4 h-4 text-emerald-600" />
              <span>{isHindi ? 'कृषक का विवरण' : 'Farmer Details'}</span>
            </span>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'कृषक का पूरा नाम:' : 'Farmer Name:'}</label>
                <input
                  type="text"
                  required
                  placeholder="उदा. रामप्रसाद वर्मा"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'पिता / पति का नाम:' : 'Father/Husband:'}</label>
                <input
                  type="text"
                  placeholder="उदा. स्व. मथुरा प्रसाद"
                  value={fatherName}
                  onChange={(e) => setFatherName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'आयु:' : 'Age:'}</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(parseInt(e.target.value, 10))}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded"
                />
              </div>
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'मोबाइल नंबर:' : 'Mobile:'}</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'आधार (अंतिम 4):' : 'Aadhaar Last 4:'}</label>
                <input
                  type="text"
                  maxLength={4}
                  value={aadhaarLast4}
                  onChange={(e) => setAadhaarLast4(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'ग्राम पंचायत:' : 'Gram Panchayat:'}</label>
                <select
                  value={gramPanchayat}
                  onChange={(e) => {
                    setGramPanchayat(e.target.value);
                    setVillage(`${e.target.value} मजरा`);
                  }}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded"
                >
                  <option value="रामपुर">रामपुर</option>
                  <option value="बिजौली">बिजौली</option>
                  <option value="कल्याणपुर">कल्याणपुर</option>
                  <option value="शिवगढ़">शिवगढ़</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'मजरा / राजस्व ग्राम:' : 'Village:'}</label>
                <input
                  type="text"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded"
                />
              </div>
            </div>
          </div>

          {/* Land Details */}
          <div className="space-y-2 pt-2 border-t border-slate-200">
            <span className="font-bold text-slate-800 flex items-center gap-1.5 pb-1 border-b border-slate-100">
              <FileSpreadsheet className="w-4 h-4 text-amber-700" />
              <span>{isHindi ? 'भूलेख एवं फसल विवरण' : 'Land & Crop Details'}</span>
            </span>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'खसरा / गाटा संख्या:' : 'Khasra No:'}</label>
                <input
                  type="text"
                  value={khasraNumber}
                  onChange={(e) => setKhasraNumber(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'खतौनी खाता संख्या:' : 'Khatauni No:'}</label>
                <input
                  type="text"
                  value={khatauniNumber}
                  onChange={(e) => setKhatauniNumber(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'दावाकृत रकबा (हे.):' : 'Area (Ha):'}</label>
                <input
                  type="number"
                  step="0.01"
                  value={claimedArea}
                  onChange={(e) => setClaimedArea(parseFloat(e.target.value) || 0.5)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-bold text-emerald-800"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'फसल:' : 'Crop:'}</label>
                <select
                  value={cropType}
                  onChange={(e) => setCropType(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded"
                >
                  <option value="गेहूं (एच.डी. 2967)">गेहूं (Wheat)</option>
                  <option value="सरसों (पीली क्रांति)">सरसों (Mustard)</option>
                  <option value="चना (देसी)">चना (Chickpea)</option>
                  <option value="मटर (सब्जी)">मटर (Peas)</option>
                  <option value="धान (बासमती)">धान (Paddy)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'सिंचाई:' : 'Irrigation:'}</label>
                <select
                  value={irrigationType}
                  onChange={(e) => setIrrigationType(e.target.value as any)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded"
                >
                  <option value="सिंचित (Irrigated)">सिंचित (Irrigated)</option>
                  <option value="असिंचित (Rainfed)">असिंचित (Rainfed)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 mb-1">{isHindi ? 'सह-खातेदार:' : 'Co-Sharers:'}</label>
                <input
                  type="number"
                  min="1"
                  value={coSharersCount}
                  onChange={(e) => setCoSharersCount(parseInt(e.target.value, 10) || 1)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium"
            >
              {isHindi ? 'रद्द करें' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg font-bold shadow-sm"
            >
              {isHindi ? 'आवेदन पंजीकृत करें' : 'Register Claim'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
