import React from 'react';
import { 
  AlertTriangle, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  Coins, 
  FileCheck2, 
  Sparkles,
  TrendingDown
} from 'lucide-react';
import { ReliefApplication } from '../types/workflow';

interface DashboardStatsProps {
  applications: ReliefApplication[];
  isHindi: boolean;
  onFilterByCard?: (stage: string) => void;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({ 
  applications, 
  isHindi,
  onFilterByCard 
}) => {
  const total = applications.length;
  const urgentCount = applications.filter(a => a.priority === 'URGENT' || a.priority === 'HIGH_DAMAGE').length;
  const scrutinyCount = applications.filter(a => a.currentStage === 'SCRUTINY').length;
  const fieldInspectCount = applications.filter(a => a.currentStage === 'FIELD_INSPECT').length;
  const decisionCount = applications.filter(a => a.currentStage === 'DECISION').length;
  const approvedCount = applications.filter(a => a.currentStage === 'APPROVED').length;

  const totalSanctionedAmount = applications
    .filter(a => a.decision?.decision === 'APPROVE' && a.decision.sanctionAmount)
    .reduce((sum, a) => sum + (a.decision?.sanctionAmount || 0), 0);

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 my-6">
      {/* 1. Urgent / Needs Attention */}
      <div 
        onClick={() => onFilterByCard && onFilterByCard('URGENT')}
        className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 shadow-sm hover:shadow-md transition-all cursor-pointer relative overflow-hidden"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-rose-700 uppercase tracking-wider">
            {isHindi ? 'अति आवश्यक' : 'Needs Attention'}
          </span>
          <div className="w-7 h-7 rounded-lg bg-rose-200 flex items-center justify-center text-rose-800">
            <AlertTriangle className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-2xl font-bold text-rose-900">{urgentCount}</span>
          <span className="text-[11px] font-medium text-rose-600 bg-rose-100 px-1.5 py-0.5 rounded">
            {isHindi ? 'SLA / गंभीर' : 'SLA Urgent'}
          </span>
        </div>
        <p className="text-[11px] text-rose-600 mt-1 line-clamp-1">
          {isHindi ? 'तत्काल मौका मुआयना या जांच' : 'Immediate field check required'}
        </p>
      </div>

      {/* 2. Step 1: Scrutiny Pending */}
      <div 
        onClick={() => onFilterByCard && onFilterByCard('SCRUTINY')}
        className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 shadow-sm hover:shadow-md transition-all cursor-pointer"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-amber-700 uppercase tracking-wider">
            {isHindi ? '1. दस्तावेज़ जांच' : '1. Scrutiny'}
          </span>
          <div className="w-7 h-7 rounded-lg bg-amber-200 flex items-center justify-center text-amber-800">
            <FileCheck2 className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-2xl font-bold text-amber-900">{scrutinyCount}</span>
          <span className="text-[11px] text-amber-600">
            {isHindi ? 'खतौनी सत्यापन' : 'Land Record'}
          </span>
        </div>
        <p className="text-[11px] text-amber-700/80 mt-1 line-clamp-1">
          {isHindi ? 'आधार व खतौनी मिलान लंबित' : 'Aadhaar & Land cross-check'}
        </p>
      </div>

      {/* 3. Step 2: Field Inspection Scheduled */}
      <div 
        onClick={() => onFilterByCard && onFilterByCard('FIELD_INSPECT')}
        className="bg-sky-50 border border-sky-200 rounded-xl p-3.5 shadow-sm hover:shadow-md transition-all cursor-pointer"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-sky-700 uppercase tracking-wider">
            {isHindi ? '2. मौका मुआयना' : '2. Field Inspect'}
          </span>
          <div className="w-7 h-7 rounded-lg bg-sky-200 flex items-center justify-center text-sky-800">
            <MapPin className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-2xl font-bold text-sky-900">{fieldInspectCount}</span>
          <span className="text-[11px] text-sky-700 bg-sky-100 px-1.5 py-0.5 rounded">
            {isHindi ? 'खेत पर जांच' : 'Site Visit'}
          </span>
        </div>
        <p className="text-[11px] text-sky-700/80 mt-1 line-clamp-1">
          {isHindi ? 'जीपीएस व फसल क्षति फोटो' : 'GPS & Photo with Panch'}
        </p>
      </div>

      {/* 4. Step 3: Decision Pending */}
      <div 
        onClick={() => onFilterByCard && onFilterByCard('DECISION')}
        className="bg-purple-50 border border-purple-200 rounded-xl p-3.5 shadow-sm hover:shadow-md transition-all cursor-pointer"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-purple-700 uppercase tracking-wider">
            {isHindi ? '3. संस्तुति/अनुमोदन' : '3. Sanctioning'}
          </span>
          <div className="w-7 h-7 rounded-lg bg-purple-200 flex items-center justify-center text-purple-800">
            <Clock className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-2xl font-bold text-purple-900">{decisionCount}</span>
          <span className="text-[11px] text-purple-700 bg-purple-100 px-1.5 py-0.5 rounded">
            {isHindi ? 'तहसीलदार कक्ष' : 'Tehsildar Queue'}
          </span>
        </div>
        <p className="text-[11px] text-purple-700/80 mt-1 line-clamp-1">
          {isHindi ? 'पंचनामा तैयार - अंतिम आदेश' : 'Panchnama ready for approval'}
        </p>
      </div>

      {/* 5. Approved & Disbursed */}
      <div 
        onClick={() => onFilterByCard && onFilterByCard('APPROVED')}
        className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 shadow-sm hover:shadow-md transition-all cursor-pointer"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
            {isHindi ? 'संस्वीकृत' : 'Sanctioned'}
          </span>
          <div className="w-7 h-7 rounded-lg bg-emerald-200 flex items-center justify-center text-emerald-800">
            <CheckCircle2 className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-2xl font-bold text-emerald-900">{approvedCount}</span>
          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
            {isHindi ? 'डीबीटी जारी' : 'DBT Released'}
          </span>
        </div>
        <p className="text-[11px] text-emerald-700/80 mt-1 line-clamp-1">
          ₹{totalSanctionedAmount.toLocaleString('en-IN')} {isHindi ? 'राहत राशि' : 'sanctioned'}
        </p>
      </div>

      {/* 6. AI & Efficiency Metric */}
      <div className="bg-gradient-to-br from-indigo-50 to-slate-100 border border-indigo-200 rounded-xl p-3.5 shadow-sm">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-indigo-700 uppercase tracking-wider">
            {isHindi ? 'औसत निस्तारण' : 'Avg Turnaround'}
          </span>
          <div className="w-7 h-7 rounded-lg bg-indigo-200 flex items-center justify-center text-indigo-800">
            <TrendingDown className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-2xl font-bold text-indigo-950">3.4 {isHindi ? 'दिन' : 'days'}</span>
          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
            -87% {isHindi ? 'तेज़' : 'faster'}
          </span>
        </div>
        <p className="text-[11px] text-indigo-800/80 mt-1 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-amber-500" />
          <span>{isHindi ? 'कागजी फाइल: 28 दिन' : 'vs 28 days paper files'}</span>
        </p>
      </div>
    </div>
  );
};
