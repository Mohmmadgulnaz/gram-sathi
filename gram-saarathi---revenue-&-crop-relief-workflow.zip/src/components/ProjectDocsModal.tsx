import React, { useState } from 'react';
import { 
  X, 
  Download, 
  BookOpen, 
  Terminal, 
  ShieldCheck, 
  Sparkles, 
  CheckCircle2, 
  Copy, 
  Check, 
  FileCode,
  TrendingDown,
  Layers
} from 'lucide-react';
import { generateProjectZip, triggerDownloadBlob } from '../services/zipExportService';

interface ProjectDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
  isHindi: boolean;
}

export const ProjectDocsModal: React.FC<ProjectDocsModalProps> = ({
  isOpen,
  onClose,
  isHindi,
}) => {
  const [isZipping, setIsZipping] = useState(false);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const blob = await generateProjectZip();
      triggerDownloadBlob(blob, 'gram-saarathi-revenue-workflow.zip');
    } catch (err) {
      console.error('Failed to create ZIP:', err);
    } finally {
      setIsZipping(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const runCommands = `# 1. Clone repository or unzip downloaded project
git clone https://github.com/mohammadgulnaz24/gram-saarathi.git
cd gram-saarathi

# 2. Install all dependencies
npm install

# 3. Start development server
npm run dev

# 4. Access in browser
# http://localhost:3000`;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full border border-slate-300 overflow-hidden my-6 flex flex-col max-h-[90vh]">
        {/* Modal Top Header */}
        <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between border-b border-emerald-700/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                {isHindi ? 'ग्राम सारथी - मूल्यांकन विवरण, डॉक्स व ज़िप डाउनलोड' : 'Project Docs, Evaluation & ZIP Download'}
              </h3>
              <p className="text-xs text-emerald-200">
                {isHindi 
                  ? 'अंतिम प्रस्तुति, स्थानीय निष्पादन कमांड व पूर्ण तकनीकी वास्तुकला' 
                  : 'Submission Guide, Local Running Commands & Architecture'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs sm:text-sm font-bold shadow-md transition-all disabled:opacity-50"
            >
              <Download className={`w-4 h-4 ${isZipping ? 'animate-bounce' : ''}`} />
              <span>{isZipping ? 'ज़िप बन रहा है...' : '📦 Download Project ZIP'}</span>
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 text-xs text-slate-700 leading-relaxed">
          {/* Quick Submission Links & Credentials Box */}
          <div className="bg-emerald-50 rounded-xl border border-emerald-300 p-4">
            <h4 className="font-bold text-emerald-950 text-sm mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700" />
              <span>{isHindi ? 'प्रस्तुति एवं टेस्ट लॉगिन क्रेडेंशियल्स' : 'Submission Details & Test Credentials'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-white p-2.5 rounded-lg border border-emerald-200">
                <span className="text-slate-500 block">लाइव लिंक (Live Link):</span>
                <span className="font-mono font-bold text-emerald-800 break-all select-all">
                  https://ais-pre-5m5sehobmlg5hdm3qhc2at-858460776490.asia-southeast1.run.app
                </span>
              </div>
              <div className="bg-white p-2.5 rounded-lg border border-emerald-200">
                <span className="text-slate-500 block">परीक्षण भूमिकाएं (Test Personas - Switchable in Top Bar):</span>
                <span className="font-medium text-slate-800 block mt-0.5">
                  1. <strong>लेखपाल / पटवारी</strong> (राजेश कुमार त्रिपाठी, हल्का 14)
                </span>
                <span className="font-medium text-slate-800 block mt-0.5">
                  2. <strong>तहसीलदार</strong> (सुनील कुमार वर्मा - वित्तीय स्वीकृति)
                </span>
                <span className="font-medium text-slate-800 block mt-0.5">
                  3. <strong>नागरिक सार्वजनिक ट्रैकर</strong> (Citizen View)
                </span>
              </div>
            </div>
          </div>

          {/* Local Running Commands */}
          <div className="bg-slate-900 rounded-xl text-slate-100 p-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-700 mb-2">
              <span className="text-xs font-bold text-amber-300 flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                <span>स्थानीय निष्पादन कमांड (How to Run Locally)</span>
              </span>
              <button
                onClick={() => copyToClipboard(runCommands, 'run-cmds')}
                className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 bg-slate-800 px-2 py-1 rounded"
              >
                {copiedSection === 'run-cmds' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'run-cmds' ? 'Copied' : 'Copy Commands'}</span>
              </button>
            </div>
            <pre className="font-mono text-xs text-emerald-300 overflow-x-auto whitespace-pre">
              {runCommands}
            </pre>
          </div>

          {/* Section 1: The Problem Chose & Who It Affects */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
            <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-700" />
              <span>1. The Problem Chosen and Who It Affects</span>
            </h4>
            <div className="space-y-2">
              <p>
                <strong>The Service:</strong> प्राकृतिक आपदा (ओलावृष्टि / असमय वर्षा व बाढ़) फसल क्षति राहत एवं कृषि इनपुट सब्सिडी संवितरण (State Disaster Relief Fund - SDRF & Revenue Code).
              </p>
              <p>
                <strong>Ground Reality Today:</strong> When unseasonal disasters hit rural areas, thousands of smallholder farmers submit paper claim slips. Ground revenue officers (Lekhpals / Patwaris) carry heavy physical cloth registers (*बस्ता, 12-साला खतौनी, खसरा सजरा*).
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-600 pl-2">
                <li><strong>Spelling & Phonetic Mismatches:</strong> Aadhaar names rarely match 40-year-old handwritten village records (*रामेश्वर प्रसाद* vs *रामेश्वर*), creating endless queries.</li>
                <li><strong>Co-Sharer Frauds:</strong> Joint family landholders often apply for the full plot area multiple times.</li>
                <li><strong>Slow On-Site Inspection:</strong> Lekhpals spend hours manually measuring acreage, verifying the statutory 33% loss threshold, and writing long legal memos (*पंचनामा*) by hand.</li>
                <li><strong>Delay & File Loss:</strong> Physical paper files take 3 to 6 months to reach the Tehsildar, leaving marginal farmers in severe financial distress.</li>
              </ul>
            </div>
          </div>

          {/* Section 2: What the Application Does & The 3 Workflow Steps */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
            <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
              <FileCode className="w-4 h-4 text-sky-700" />
              <span>2. What the Application Does & The 3 Workflow Steps</span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-bold text-amber-800 block text-xs">चरण 1: दस्तावेज़ व खतौनी सत्यापन</span>
                <p className="mt-1 text-[11px] text-slate-600">
                  Cross-checks applicant Aadhaar, Bank DBT status, and Bhulekh Khatauni parcel. Analyzes phonetic spelling differences and validates legal landholding share.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-bold text-sky-800 block text-xs">चरण 2: मौका मुआयना व फसल क्षति</span>
                <p className="mt-1 text-[11px] text-slate-600">
                  Captures live GPS coordinates, weather event date, geotagged crop photos, village panch witnesses, and Hindi speech-to-text field notes.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-bold text-purple-800 block text-xs">चरण 3: संस्तुति व अंतिम अनुमोदन</span>
                <p className="mt-1 text-[11px] text-slate-600">
                  Auto-computes SDRF grant scale (₹17,000/Ha irrigated). AI drafts official legal Hindi Panchnama. Officer approves (with QR sanction order), returns for fix, or rejects with rule citation.
                </p>
              </div>
            </div>
          </div>

          {/* Section 3: Where AI Helps and Why */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
            <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>3. Where AI Helps and Why</span>
            </h4>
            <div className="space-y-2">
              <p>
                <strong>AI Assists, Officer Decides:</strong> The AI never takes the decision away from the government official; it automates the tedious clerical and calculation work:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                <div className="p-2.5 bg-white rounded border border-slate-200">
                  <strong>⚡ Step 1: Document & Name Cross-Matcher:</strong> Resolves phonetic Devanagari variations, checks co-sharer land ceilings, and checks duplicate claim risks.
                </div>
                <div className="p-2.5 bg-white rounded border border-slate-200">
                  <strong>⚡ Step 2: Visual Crop Damage & GPS Sanity:</strong> Analyzes field photos for lodging/inundation, estimates damage %, and verifies GPS coords vs Panchayat boundaries.
                </div>
                <div className="p-2.5 bg-white rounded border border-slate-200">
                  <strong>⚡ Step 3: Legal Hindi Panchnama Drafter:</strong> Generates dignified, standard government Panchnama citing SDRF circulars, saving officers 40+ minutes per file.
                </div>
                <div className="p-2.5 bg-white rounded border border-slate-200">
                  <strong>⚡ Conversational AI Assistant:</strong> Pure Hindi interactive chat/voice helper to clarify revenue codes and disaster relief rules on the spot.
                </div>
              </div>
            </div>
          </div>

          {/* Section 4: Impact Measurement & Why It Will Work */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
            <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-emerald-700" />
              <span>4. How to Measure Impact and Why It Will Work</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
              <div className="p-2 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="text-xl font-black text-emerald-900">3.4 दिन</span>
                <span className="block text-[10px] text-emerald-700 font-medium">निस्तारण समय (vs 28 दिन)</span>
              </div>
              <div className="p-2 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="text-xl font-black text-emerald-900">0 फाइल</span>
                <span className="block text-[10px] text-emerald-700 font-medium">खोई या लंबित कागजी फाइल</span>
              </div>
              <div className="p-2 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="text-xl font-black text-emerald-900">100%</span>
                <span className="block text-[10px] text-emerald-700 font-medium">विधिक ऑडिट अनुपालन</span>
              </div>
              <div className="p-2 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="text-xl font-black text-emerald-900">3+ घंटे/दिन</span>
                <span className="block text-[10px] text-emerald-700 font-medium">लेखपाल समय बचत</span>
              </div>
            </div>
            <p className="mt-2 text-slate-600">
              <strong>Why It Works on the Ground:</strong> Built in the local Hindi language using authentic revenue terminology (*खतौनी, खसरा, मौका मुआयना, पंचनामा*). Features Field Mode for high sunlight visibility, voice notes, and offline-resilient heuristic fallbacks so work never halts.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-100 p-4 border-t border-slate-300 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-mono">
            Gram Saarathi v1.0.0 • AI Studio Build
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold"
          >
            {isHindi ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
