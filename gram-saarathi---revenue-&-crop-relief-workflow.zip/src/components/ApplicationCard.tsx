import React from 'react';
import { 
  Clock, 
  MapPin, 
  User, 
  FileCheck2, 
  AlertTriangle, 
  ChevronRight, 
  Sparkles, 
  Wheat, 
  CheckCircle2, 
  XCircle, 
  RotateCcw,
  ShieldAlert
} from 'lucide-react';
import { ReliefApplication, ApplicationStage } from '../types/workflow';

interface ApplicationCardProps {
  app: ReliefApplication;
  isHindi: boolean;
  isFieldMode: boolean;
  onSelect: (app: ReliefApplication) => void;
  onQuickVerify?: (app: ReliefApplication) => void;
}

export const ApplicationCard: React.FC<ApplicationCardProps> = ({
  app,
  isHindi,
  isFieldMode,
  onSelect,
}) => {
  // Stepper helper
  const getStageStep = (stage: ApplicationStage): number => {
    switch (stage) {
      case 'SCRUTINY': return 1;
      case 'FIELD_INSPECT': return 2;
      case 'DECISION': return 3;
      case 'APPROVED': return 4;
      case 'RETURNED': return 1;
      case 'REJECTED': return 3;
    }
  };

  const stepNumber = getStageStep(app.currentStage);

  // Status badges
  const getStatusBadge = () => {
    switch (app.currentStage) {
      case 'SCRUTINY':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>{isHindi ? 'चरण 1: दस्तावेज़ जांच' : '1. Scrutiny'}</span>
          </span>
        );
      case 'FIELD_INSPECT':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-100 text-sky-800 border border-sky-300">
            <MapPin className="w-3.5 h-3.5" />
            <span>{isHindi ? 'चरण 2: मौका मुआयना' : '2. Field Inspection'}</span>
          </span>
        );
      case 'DECISION':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-100 text-purple-800 border border-purple-300">
            <Clock className="w-3.5 h-3.5" />
            <span>{isHindi ? 'चरण 3: संस्तुति/अनुमोदन' : '3. Sanctioning'}</span>
          </span>
        );
      case 'APPROVED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{isHindi ? 'संस्वीकृत (Approved)' : 'Approved'}</span>
          </span>
        );
      case 'RETURNED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-orange-100 text-orange-800 border border-orange-300">
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isHindi ? 'संशोधन हेतु वापस' : 'Returned'}</span>
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-300">
            <XCircle className="w-3.5 h-3.5" />
            <span>{isHindi ? 'अस्वीकृत (Rejected)' : 'Rejected'}</span>
          </span>
        );
    }
  };

  const getPriorityBadge = () => {
    if (app.priority === 'URGENT') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-rose-600 text-white animate-pulse">
          <AlertTriangle className="w-3 h-3" />
          <span>{isHindi ? 'अति आवश्यक (SLA 48 घंटे)' : 'Urgent (SLA)'}</span>
        </span>
      );
    }
    if (app.priority === 'HIGH_DAMAGE') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-amber-600 text-white">
          <ShieldAlert className="w-3 h-3" />
          <span>{isHindi ? 'गंभीर क्षति (>70%)' : 'High Damage'}</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-slate-200 text-slate-700">
        <span>{isHindi ? app.applicant.category : 'Marginal Farmer'}</span>
      </span>
    );
  };

  // Action button text
  const getActionBtnText = () => {
    switch (app.currentStage) {
      case 'SCRUTINY': return isHindi ? 'दस्तावेज़ जांचें' : 'Verify Docs';
      case 'FIELD_INSPECT': return isHindi ? 'मौका मुआयना करें' : 'Conduct Field Visit';
      case 'DECISION': return isHindi ? 'संस्तुति/आदेश दें' : 'Review & Sanction';
      case 'APPROVED': return isHindi ? 'स्वीकृति आदेश देखें' : 'View Sanction Order';
      case 'RETURNED': return isHindi ? 'आपत्ति विवरण देखें' : 'View Objections';
      case 'REJECTED': return isHindi ? 'अस्वीकृति आदेश देखें' : 'View Rejection';
    }
  };

  return (
    <div 
      className={`bg-white rounded-xl border transition-all duration-200 hover:shadow-md ${
        app.priority === 'URGENT' 
          ? 'border-rose-300 ring-1 ring-rose-200' 
          : 'border-slate-200 hover:border-emerald-300'
      } ${isFieldMode ? 'p-5' : 'p-4'}`}
    >
      {/* Top Header: ID & Badges */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
        <div className="flex items-center space-x-2">
          <span className="font-mono text-xs font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
            {app.id}
          </span>
          {getStatusBadge()}
          {getPriorityBadge()}
        </div>

        {/* SLA / Submission date */}
        <div className="flex items-center gap-1 text-xs text-slate-500">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>
            {isHindi ? 'पंजीकरण: ' : 'Submitted: '}
            {new Date(app.submissionDate).toLocaleDateString(isHindi ? 'hi-IN' : 'en-US', {
              day: 'numeric',
              month: 'short',
            })}
          </span>
        </div>
      </div>

      {/* Stepper Progress Bar */}
      <div className="py-2.5">
        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 mb-1 px-1">
          <span className={stepNumber >= 1 ? 'text-emerald-700 font-bold' : ''}>
            {isHindi ? '1. दस्तावेज़ जांच' : '1. Scrutiny'}
          </span>
          <span className={stepNumber >= 2 ? 'text-emerald-700 font-bold' : ''}>
            {isHindi ? '2. मौका मुआयना' : '2. Field Visit'}
          </span>
          <span className={stepNumber >= 3 ? 'text-emerald-700 font-bold' : ''}>
            {isHindi ? '3. संस्तुति/अनुमोदन' : '3. Sanction'}
          </span>
        </div>
        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden flex">
          <div 
            className={`h-full transition-all duration-300 ${
              app.currentStage === 'APPROVED' 
                ? 'bg-emerald-600 w-full' 
                : app.currentStage === 'REJECTED'
                ? 'bg-rose-500 w-full'
                : app.currentStage === 'RETURNED'
                ? 'bg-orange-500 w-1/3'
                : stepNumber === 1 
                ? 'bg-amber-500 w-1/3' 
                : stepNumber === 2 
                ? 'bg-sky-500 w-2/3' 
                : 'bg-purple-600 w-full'
            }`}
          />
        </div>
      </div>

      {/* Middle details: Applicant & Land Summary */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 py-2 text-sm">
        {/* Applicant Name & Village */}
        <div className="md:col-span-5">
          <div className="flex items-start gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900 leading-tight">
                {isHindi ? app.applicant.name : app.applicant.nameEn}
              </h4>
              <p className="text-xs text-slate-500">
                {app.applicant.fatherOrHusbandName} • {isHindi ? 'आयु' : 'Age'}: {app.applicant.age}
              </p>
              <div className="flex items-center gap-1 text-xs text-slate-600 mt-0.5">
                <MapPin className="w-3 h-3 text-slate-400" />
                <span>
                  {isHindi 
                    ? `ग्रा.पं. ${app.applicant.gramPanchayat}, म. ${app.applicant.village}`
                    : `${app.applicant.villageEn}, GP: ${app.applicant.gramPanchayatEn}`}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Land Record & Crop Details */}
        <div className="md:col-span-4 bg-slate-50 rounded-lg p-2 border border-slate-200/80 text-xs">
          <div className="flex items-center justify-between font-medium text-slate-800">
            <span className="flex items-center gap-1">
              <Wheat className="w-3.5 h-3.5 text-amber-600" />
              <span>{isHindi ? app.landDetails.cropType : app.landDetails.cropTypeEn}</span>
            </span>
            <span className="font-semibold text-emerald-800">
              {app.landDetails.claimedAreaHectare} {isHindi ? 'हेक्टेयर' : 'Ha'}
            </span>
          </div>
          <div className="mt-1 flex items-center justify-between text-slate-600 text-[11px]">
            <span>
              {isHindi ? 'खसरा संख्या: ' : 'Khasra No: '} 
              <strong className="text-slate-800">{app.landDetails.khasraNumber}</strong>
            </span>
            <span>
              {isHindi ? 'खाता: ' : 'Khata: '} 
              <strong className="text-slate-800">{app.landDetails.khatauniNumber}</strong>
            </span>
          </div>
          {app.fieldInspection && (
            <div className="mt-1 pt-1 border-t border-slate-200 flex justify-between items-center text-[11px]">
              <span className="text-slate-500">{isHindi ? 'प्रमाणित फसल क्षति:' : 'Assessed Loss:'}</span>
              <span className={`font-bold ${app.fieldInspection.assessedDamagePercentage >= 70 ? 'text-rose-700' : 'text-amber-700'}`}>
                {app.fieldInspection.assessedDamagePercentage}%
              </span>
            </div>
          )}
        </div>

        {/* AI Insight Snippet */}
        <div className="md:col-span-3 flex flex-col justify-between">
          {app.aiAnalyses.step1Docs || app.aiAnalyses.step2Field ? (
            <div className="bg-indigo-50/70 border border-indigo-200/80 rounded-lg p-2 text-xs text-indigo-900">
              <div className="flex items-center gap-1 font-semibold text-[11px] text-indigo-700">
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span>{isHindi ? 'एआई विश्लेषण उपलब्ध' : 'AI Verified'}</span>
              </div>
              <p className="text-[11px] line-clamp-2 mt-0.5 text-indigo-800/90">
                {app.aiAnalyses.step2Field?.summary || app.aiAnalyses.step1Docs?.summary}
              </p>
            </div>
          ) : (
            <div className="text-[11px] text-slate-500 italic flex items-center gap-1 px-1">
              <span>{isHindi ? 'दस्तावेज़ सत्यापन प्रतीक्षारत' : 'Pending verification'}</span>
            </div>
          )}

          {/* Action Trigger Button */}
          <button
            onClick={() => onSelect(app)}
            className={`w-full mt-2 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all shadow-sm ${
              app.currentStage === 'APPROVED'
                ? 'bg-emerald-700 hover:bg-emerald-600 text-white'
                : app.currentStage === 'RETURNED'
                ? 'bg-orange-600 hover:bg-orange-500 text-white'
                : 'bg-emerald-800 hover:bg-emerald-700 text-white'
            }`}
          >
            <span>{getActionBtnText()}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
