import JSZip from 'jszip';

export async function generateProjectZip(): Promise<Blob> {
  const zip = new JSZip();

  // Project configuration files
  zip.file('package.json', JSON.stringify({
    name: "gram-saarathi-revenue-workflow",
    private: true,
    version: "1.0.0",
    type: "module",
    scripts: {
      "dev": "tsx server.ts",
      "build": "vite build",
      "preview": "vite preview",
      "start": "tsx server.ts",
      "clean": "rm -rf dist server.js",
      "lint": "tsc --noEmit"
    },
    dependencies: {
      "@google/genai": "^2.4.0",
      "@tailwindcss/vite": "^4.3.3",
      "@vitejs/plugin-react": "^6.1.1",
      "dotenv": "^17.2.3",
      "express": "^4.21.2",
      "jszip": "^3.10.1",
      "lucide-react": "^0.546.0",
      "motion": "^12.23.24",
      "react": "^19.0.1",
      "react-dom": "^19.0.1",
      "vite": "^8.3.0"
    },
    devDependencies: {
      "@types/express": "^4.17.21",
      "@types/jszip": "^3.4.1",
      "@types/node": "^22.14.0",
      "@types/react": "^19.3.0",
      "@types/react-dom": "^19.3.0",
      "autoprefixer": "^10.4.21",
      "esbuild": "^0.25.0",
      "tailwindcss": "^4.3.3",
      "tsx": "^4.21.0",
      "typescript": "^7.0.2"
    }
  }, null, 2));

  zip.file('tsconfig.json', JSON.stringify({
    compilerOptions: {
      target: "ES2022",
      experimentalDecorators: true,
      useDefineForClassFields: false,
      module: "ESNext",
      types: ["vite/client"],
      lib: ["ES2022", "DOM", "DOM.Iterable"],
      skipLibCheck: true,
      moduleResolution: "bundler",
      isolatedModules: true,
      moduleDetection: "force",
      allowJs: true,
      jsx: "react-jsx",
      paths: { "@/*": ["./*"] },
      allowImportingTsExtensions: true,
      noEmit: true
    },
    exclude: ["dist"]
  }, null, 2));

  zip.file('vite.config.ts', `import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
});
`);

  zip.file('.env.example', `# GEMINI_API_KEY: Required for Gemini AI API calls.
GEMINI_API_KEY="your_api_key_here"
PORT=3000
`);

  // Include comprehensive README
  const readmeResponse = await fetch('/README.md').catch(() => null);
  if (readmeResponse && readmeResponse.ok) {
    const text = await readmeResponse.text();
    zip.file('README.md', text);
  } else {
    zip.file('README.md', `# Gram Saarathi - Revenue & Crop Disaster Relief Workflow
Run \`npm install\` followed by \`npm run dev\` to start the server.`);
  }

  // Fetch key source files to bundle directly
  const filesToFetch = [
    'index.html',
    'metadata.json',
    'server.ts',
    'src/main.tsx',
    'src/index.css',
    'src/App.tsx',
    'src/types/workflow.ts',
    'src/data/mockApplications.ts',
    'src/services/aiService.ts',
    'src/services/zipExportService.ts'
  ];

  for (const f of filesToFetch) {
    try {
      const res = await fetch(`/${f}`);
      if (res.ok) {
        const content = await res.text();
        zip.file(f, content);
      }
    } catch (e) {
      // Ignore if not accessible
    }
  }

  return await zip.generateAsync({ type: 'blob' });
}

export function triggerDownloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
